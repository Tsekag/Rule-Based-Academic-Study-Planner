using AcademicStudyPlanner.Views;

namespace AcademicStudyPlanner
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new SideBar());   // Now works
        }
    }
}
