using System;
using System.Collections.Generic;
using System.Linq;

namespace AcademicStudyPlanner.Models
{
    public class Availability
    {
        // Dictionary mapping Day of Week to a list of (StartHour, EndHour) tuples
        public Dictionary<DayOfWeek, List<(int, int)>> AvailableSlots { get; set; } = new();

        public double TotalHoursPerWeek => AvailableSlots.Values
            .SelectMany(slots => slots)
            .Sum(slot => slot.Item2 - slot.Item1);
    }
}