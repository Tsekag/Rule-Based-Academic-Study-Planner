using System;

namespace AcademicStudyPlanner.Models
{
    /// <summary>
    /// Represents an assignment with all necessary properties for planning.
    /// </summary>
    public class Assignment
    {
        public string CourseName { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public TimeSpan EstimatedDuration { get; set; } = TimeSpan.Zero;
        public DateTime DueDate { get; set; } = DateTime.Now;
        public DateTime StartDate { get; set; } = DateTime.Now;
        public bool IsCompleted { get; set; } = false;
        public string Id { get; set; } = Guid.NewGuid().ToString(); // Unique identifier for editing/deleting
    }
}