using System;
using System.Collections.Generic;
using System.Linq;

namespace AcademicStudyPlanner.Models
{
    /// <summary>
    /// Represents a grade scale with letter grades, percentage ranges, and grade points.
    /// </summary>
    public class GradeScale
    {
        public List<GradeScaleItem> Items { get; set; } = new();

        /// <summary>
        /// Gets the preset university-standard grade scale.
        /// </summary>
        public static GradeScale GetPreset()
        {
            return new GradeScale
            {
                Items = new List<GradeScaleItem>
                {
                    new GradeScaleItem { Letter = "A", MinPercent = 95, MaxPercent = 100, GradePoints = 4.0 },
                    new GradeScaleItem { Letter = "A-", MinPercent = 90, MaxPercent = 94, GradePoints = 3.7 },
                    new GradeScaleItem { Letter = "B+", MinPercent = 87, MaxPercent = 89, GradePoints = 3.3 },
                    new GradeScaleItem { Letter = "B", MinPercent = 85, MaxPercent = 86, GradePoints = 3.0 },
                    new GradeScaleItem { Letter = "B-", MinPercent = 80, MaxPercent = 84, GradePoints = 2.7 },
                    new GradeScaleItem { Letter = "C+", MinPercent = 77, MaxPercent = 79, GradePoints = 2.3 },
                    new GradeScaleItem { Letter = "C", MinPercent = 75, MaxPercent = 76, GradePoints = 2.0 },
                    new GradeScaleItem { Letter = "C-", MinPercent = 70, MaxPercent = 74, GradePoints = 1.7 },
                    new GradeScaleItem { Letter = "D+", MinPercent = 67, MaxPercent = 69, GradePoints = 1.3 },
                    new GradeScaleItem { Letter = "D", MinPercent = 65, MaxPercent = 66, GradePoints = 1.0 },
                    new GradeScaleItem { Letter = "F", MinPercent = 0, MaxPercent = 64, GradePoints = 0.0 }
                }
            };
        }

        /// <summary>
        /// Gets letter grade and percentage for a given GPA using this grade scale.
        /// </summary>
        public (string Letter, int Percent) GetLetterAndPercent(double gpa)
        {
            // Find the grade scale item with matching grade points (closest match)
            var item = Items
                .OrderByDescending(i => i.GradePoints)
                .FirstOrDefault(i => gpa >= i.GradePoints - 0.05);

            if (item != null)
            {
                return (item.Letter, (item.MinPercent + item.MaxPercent) / 2);
            }

            // Default to lowest grade
            var lowest = Items.OrderBy(i => i.GradePoints).FirstOrDefault();
            return lowest != null ? (lowest.Letter, lowest.MinPercent) : ("F", 0);
        }

        /// <summary>
        /// Gets grade points for a given percentage.
        /// </summary>
        public double GetGradePoints(int percent)
        {
            var item = Items.FirstOrDefault(i => percent >= i.MinPercent && percent <= i.MaxPercent);
            return item?.GradePoints ?? 0.0;
        }

        /// <summary>
        /// Validates the grade scale to ensure no overlapping ranges and valid values.
        /// </summary>
        public bool Validate(out string errorMessage)
        {
            if (Items == null || Items.Count == 0)
            {
                errorMessage = "Grade scale must contain at least one item.";
                return false;
            }

            // Check for overlapping ranges
            var sorted = Items.OrderBy(i => i.MinPercent).ToList();
            for (int i = 0; i < sorted.Count - 1; i++)
            {
                if (sorted[i].MaxPercent >= sorted[i + 1].MinPercent)
                {
                    errorMessage = $"Overlapping percentage ranges: {sorted[i].Letter} and {sorted[i + 1].Letter}";
                    return false;
                }
            }

            // Check for valid percentages
            foreach (var item in Items)
            {
                if (item.MinPercent < 0 || item.MaxPercent > 100 || item.MinPercent > item.MaxPercent)
                {
                    errorMessage = $"Invalid percentage range for {item.Letter}: {item.MinPercent}-{item.MaxPercent}";
                    return false;
                }
            }

            errorMessage = string.Empty;
            return true;
        }
    }

    /// <summary>
    /// Represents a single grade scale item.
    /// </summary>
    public class GradeScaleItem
    {
        public string Letter { get; set; } = string.Empty;
        public int MinPercent { get; set; }
        public int MaxPercent { get; set; }
        public double GradePoints { get; set; }
    }
}

