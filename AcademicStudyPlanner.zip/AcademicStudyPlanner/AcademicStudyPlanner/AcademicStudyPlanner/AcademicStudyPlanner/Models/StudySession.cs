using System;
using System.Drawing;

namespace AcademicStudyPlanner.Models
{
    /// <summary>
    /// Represents a study session scheduled in the calendar.
    /// </summary>
    public class StudySession
    {
        public string CourseName { get; set; } = string.Empty;
        public string TaskTitle { get; set; } = string.Empty;
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public TimeSpan Duration => EndTime - StartTime;
        public Color SessionColor { get; set; } = Color.MediumSeaGreen;
        public int Priority { get; set; } = 0; // Higher number = higher priority

        /// <summary>
        /// Gets the day of week (0=Sunday, 1=Monday, etc.)
        /// </summary>
        public DayOfWeek DayOfWeek => StartTime.DayOfWeek;

        /// <summary>
        /// Gets the hour of day (0-23)
        /// </summary>
        public int Hour => StartTime.Hour;
    }
}



