using System;
using System.Collections.Generic;

namespace AcademicStudyPlanner.Models
{
    public class UserData
    {
        public List<CourseInfo> Courses { get; set; } = new();
        public List<Assignment> Assignments { get; set; } = new();
        public Availability Availability { get; set; } = new();
        public List<StudySession> StudyPlan { get; set; } = new();

        // SMART DATA FIELDS
        public double CurrentGPA { get; set; } = 2.0;
        public double TargetGPA { get; set; } = 3.5;
        public int TotalYearlyCreditHours { get; set; } = 0;
        public int PastCompletedCreditHours { get; set; } = 0;

        // Grade Scale
        public GradeScale? GradeScale { get; set; }
        public bool UseCustomGradeScale { get; set; } = false;

        // Semester Dates
        public DateTime SemesterStartDate { get; set; } = DateTime.Today;
        public DateTime SemesterEndDate { get; set; } = DateTime.Today.AddMonths(4);
    }
}