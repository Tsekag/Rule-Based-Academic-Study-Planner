namespace AcademicStudyPlanner.Models
{
    /// <summary>
    /// Represents the type of focus for a study session.
    /// </summary>
    public enum FocusType
    {
        GeneralReview,
        SpecificTask
    }
}