using System;

namespace AcademicStudyPlanner.Models
{
    public class CourseInfo
    {
        public string Name { get; set; } = string.Empty;
        public int CreditHours { get; set; }
        public string Strength { get; set; } = string.Empty;

        // Course-specific dates
        public DateTime StartDate { get; set; } = DateTime.Today;
        public DateTime EndDate { get; set; } = DateTime.Today.AddMonths(4);

        // optional fields for analysis results
        public double TargetGpa { get; set; }
        public string Letter { get; set; } = string.Empty;
        public int Score { get; set; }
    }
}