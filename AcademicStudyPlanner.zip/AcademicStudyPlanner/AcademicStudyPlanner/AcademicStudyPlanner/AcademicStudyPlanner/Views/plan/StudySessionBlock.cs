﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace AcademicStudyPlanner.Views.plan
{
    public partial class StudySessionBlock : UserControl
    {
        public string CourseName { get; set; } = "";
        public string TaskTitle { get; set; } = "";
        public Color DifficultyColor { get; set; } = Color.SkyBlue;

        private Label lblCourse = new Label();
        private Label lblTask = new Label();

        public StudySessionBlock()
        {
            InitializeComponent();
            SetupLabels();
        }

        private void SetupLabels()
        {
            // Configure Course Label (Top)
            lblCourse.Dock = DockStyle.Top;
            lblCourse.TextAlign = ContentAlignment.BottomCenter;
            lblCourse.Height = 25;
            lblCourse.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblCourse.BackColor = Color.Transparent;

            // Configure Task Label (Fill)
            lblTask.Dock = DockStyle.Fill;
            lblTask.TextAlign = ContentAlignment.TopCenter;
            lblTask.Font = new Font("Segoe UI", 8.5F, FontStyle.Regular);
            lblTask.BackColor = Color.Transparent;

            this.Controls.Add(lblTask);
            this.Controls.Add(lblCourse);
        }

        public void UpdateDisplay()
        {
            this.BackColor = DifficultyColor;

            // Set Text
            lblCourse.Text = CourseName;
            lblTask.Text = TaskTitle;

            // Smart Color: Make text white on dark backgrounds, black on light ones
            Color contrast = GetContrastColor(DifficultyColor);
            lblCourse.ForeColor = contrast;
            lblTask.ForeColor = contrast;
        }

        private Color GetContrastColor(Color color)
        {
            double luminance = (0.299 * color.R + 0.587 * color.G + 0.114 * color.B) / 255;
            return luminance > 0.5 ? Color.Black : Color.White;
        }
    }
}