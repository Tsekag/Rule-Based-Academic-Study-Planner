﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace AcademicStudyPlanner.Views.plan
{
    partial class CalendarView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;
        private Panel headerPanel;
        private Button btnPrevWeek;
        private Button btnNextWeek;
        private Button btnGeneratePlan;
        private Label lblCurrentDateRange;
        private Panel scrollPanel;
        private TableLayoutPanel gridCalendar;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Initialize controls and layout (moved from code-behind so designer owns UI).
        /// </summary>
        private void InitializeComponent()
        {
            headerPanel = new Panel();
            btnPrevWeek = new Button();
            btnNextWeek = new Button();
            lblCurrentDateRange = new Label();
            btnGeneratePlan = new Button();
            scrollPanel = new Panel();
            gridCalendar = new TableLayoutPanel();
            headerPanel.SuspendLayout();
            scrollPanel.SuspendLayout();
            SuspendLayout();
            // 
            // headerPanel
            // 
            headerPanel.BackColor = Color.WhiteSmoke;
            headerPanel.Controls.Add(btnPrevWeek);
            headerPanel.Controls.Add(btnNextWeek);
            headerPanel.Controls.Add(lblCurrentDateRange);
            headerPanel.Controls.Add(btnGeneratePlan);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Location = new Point(0, 0);
            headerPanel.Name = "headerPanel";
            headerPanel.Padding = new Padding(8);
            headerPanel.Size = new Size(900, 48);
            headerPanel.TabIndex = 1;
            // 
            // btnPrevWeek
            // 
            btnPrevWeek.Anchor = AnchorStyles.Left;
            btnPrevWeek.AutoSize = true;
            btnPrevWeek.Location = new Point(8, 10);
            btnPrevWeek.Name = "btnPrevWeek";
            btnPrevWeek.Size = new Size(83, 25);
            btnPrevWeek.TabIndex = 0;
            btnPrevWeek.Text = "< Prev Week";
            btnPrevWeek.Click += BtnPrevWeek_Click;
            // 
            // btnNextWeek
            // 
            btnNextWeek.Anchor = AnchorStyles.Left;
            btnNextWeek.AutoSize = true;
            btnNextWeek.Location = new Point(112, 10);
            btnNextWeek.Name = "btnNextWeek";
            btnNextWeek.Size = new Size(85, 25);
            btnNextWeek.TabIndex = 1;
            btnNextWeek.Text = "Next Week >";
            btnNextWeek.Click += BtnNextWeek_Click;
            // 
            // lblCurrentDateRange
            // 
            lblCurrentDateRange.Anchor = AnchorStyles.Top;
            lblCurrentDateRange.AutoSize = true;
            lblCurrentDateRange.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblCurrentDateRange.Location = new Point(590, 13);
            lblCurrentDateRange.Name = "lblCurrentDateRange";
            lblCurrentDateRange.Size = new Size(0, 19);
            lblCurrentDateRange.TabIndex = 2;
            // 
            // btnGeneratePlan
            // 
            btnGeneratePlan.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnGeneratePlan.AutoSize = true;
            btnGeneratePlan.BackColor = Color.FromArgb(30, 136, 229);
            btnGeneratePlan.FlatAppearance.BorderSize = 0;
            btnGeneratePlan.FlatStyle = FlatStyle.Flat;
            btnGeneratePlan.ForeColor = Color.White;
            btnGeneratePlan.Location = new Point(850, 8);
            btnGeneratePlan.Name = "btnGeneratePlan";
            btnGeneratePlan.Size = new Size(110, 30);
            btnGeneratePlan.TabIndex = 3;
            btnGeneratePlan.Text = "Generate Plan";
            btnGeneratePlan.UseVisualStyleBackColor = false;
            btnGeneratePlan.Click += BtnGeneratePlan_Click;
            // 
            // scrollPanel
            // 
            scrollPanel.AutoScroll = true;
            scrollPanel.BackColor = Color.White;
            scrollPanel.Controls.Add(gridCalendar);
            scrollPanel.Dock = DockStyle.Fill;
            scrollPanel.Location = new Point(0, 48);
            scrollPanel.Name = "scrollPanel";
            scrollPanel.Size = new Size(900, 552);
            scrollPanel.TabIndex = 0;
            scrollPanel.Paint += scrollPanel_Paint;
            // 
            // gridCalendar
            // 
            gridCalendar.AutoSize = true;
            gridCalendar.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            gridCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            gridCalendar.Dock = DockStyle.Top;
            gridCalendar.Location = new Point(0, 0);
            gridCalendar.Name = "gridCalendar";
            gridCalendar.Size = new Size(900, 1);
            gridCalendar.TabIndex = 0;
            // 
            // CalendarView
            // 
            BackColor = Color.White;
            Controls.Add(scrollPanel);
            Controls.Add(headerPanel);
            Name = "CalendarView";
            Size = new Size(900, 600);
            headerPanel.ResumeLayout(false);
            headerPanel.PerformLayout();
            scrollPanel.ResumeLayout(false);
            scrollPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
    }
}
