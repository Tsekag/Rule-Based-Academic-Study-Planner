﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AcademicStudyPlanner.Views.plan
{
    public partial class CalendarView : UserControl
    {
        private const int StartHour = 8;   // 8 AM
        private const int EndHour = 22;    // 10 PM
        private const int HoursPerDay = EndHour - StartHour;
        private DateTime _weekStart;
        public CalendarView()
        {
            InitializeComponent();
            InitializeGrid();
            SetWeekStart(DateTime.Today);
            UpdateDateRangeLabel();
        }

        /// <summary>
        /// Raised when the Generate Plan button is clicked so the parent
        /// container (PlannerEngine) can handle workflow selection and planning.
        /// </summary>
        public event EventHandler? GeneratePlanClicked;

        private void InitializeGrid()
        {
            gridCalendar.SuspendLayout();
            gridCalendar.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single; // Show the grid lines
            gridCalendar.BackColor = Color.White;

            gridCalendar.ColumnCount = 8;
            gridCalendar.RowCount = HoursPerDay + 1;

            gridCalendar.ColumnStyles.Clear();
            gridCalendar.RowStyles.Clear();

            gridCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70F));
            for (int col = 1; col <= 7; col++)
                gridCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 7F));

            gridCalendar.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Header row

            // Header Row Labels
            string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
            gridCalendar.Controls.Add(new Label { Dock = DockStyle.Fill, BackColor = Color.WhiteSmoke }, 0, 0);

            for (int d = 0; d < 7; d++)
            {
                gridCalendar.Controls.Add(new Label
                {
                    Text = days[d],
                    Dock = DockStyle.Fill,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    BackColor = Color.WhiteSmoke
                }, d + 1, 0);
            }

            // Time Rows
            for (int h = 0; h < HoursPerDay; h++)
            {
                gridCalendar.RowStyles.Add(new RowStyle(SizeType.Absolute, 60F));
                int hour = StartHour + h;

                gridCalendar.Controls.Add(new Label
                {
                    Text = DateTime.Today.AddHours(hour).ToString("htt").ToLower(),
                    Dock = DockStyle.Fill,
                    TextAlign = ContentAlignment.TopRight,
                    Padding = new Padding(0, 5, 5, 0),
                    Font = new Font("Segoe UI", 8F),
                    ForeColor = Color.Gray
                }, 0, h + 1);

                // NOTE: We no longer add empty white Panels here! 
                // This allows the StudySessionBlocks to be visible.
            }

            gridCalendar.ResumeLayout();
        }
        public void PopulateCalendar(List<AcademicStudyPlanner.Models.StudySession> sessions)
        {
            ClearCalendar(); // Remove old blocks first

            foreach (var session in sessions)
            {
                // 1. Calculate Day Column (Mon=1, Tue=2 ... Sun=7)
                // C# DayOfWeek: Sunday=0, Monday=1. 
                int dayColumn = (int)session.DayOfWeek;
                if (dayColumn == 0) dayColumn = 7; // Move Sunday to the end

                // 2. Calculate Start Row (Relative to 8 AM)
                int startRow = session.StartTime.Hour - StartHour;

                // 3. Calculate Duration in Hours
                int duration = (int)Math.Ceiling(session.Duration.TotalHours);

                // 4. Only add if it's within our visible time range (8am - 10pm)
                if (startRow >= 0 && startRow < HoursPerDay)
                {
                    AddSession(
                        session.CourseName,
                        session.TaskTitle,
                        dayColumn,
                        startRow,
                        duration,
                        session.SessionColor
                    );
                }
            }
        }

        /// <summary>
        /// Removes all StudySessionBlock controls from the calendar grid.
        /// </summary>
        public void ClearCalendar()
        {
            var toRemove = gridCalendar.Controls.OfType<StudySessionBlock>().ToList();
            foreach (var control in toRemove)
            {
                gridCalendar.Controls.Remove(control);
                control.Dispose();
            }
        }
        /// <summary>
        /// Adds a study session block to the calendar.
        /// dayColumn: 1-7 (1 = Monday, 7 = Sunday).
        /// startRow & durationRows are 0-based hour indexes relative to 8 AM.
        /// </summary>
        public void AddSession(string course, string task, int dayCol, int startRow, int duration, Color color)
        {
            var block = new StudySessionBlock
            {
                CourseName = course,
                TaskTitle = task,
                DifficultyColor = color,
                Dock = DockStyle.Fill,
                Margin = new Padding(2)
            };

            gridCalendar.Controls.Add(block, dayCol, startRow + 1);
            gridCalendar.SetRowSpan(block, duration);

            // THIS LINE IS THE KEY TO SHOWING THE NAMES:
            block.UpdateDisplay();

            block.BringToFront();
        }

        private void BtnPrevWeek_Click(object? sender, EventArgs e) { SetWeekStart(_weekStart.AddDays(-7)); UpdateDateRangeLabel(); }

        private void BtnNextWeek_Click(object? sender, EventArgs e) { SetWeekStart(_weekStart.AddDays(7)); UpdateDateRangeLabel(); }

        private void BtnGeneratePlan_Click(object? sender, EventArgs e) => GeneratePlanClicked?.Invoke(this, EventArgs.Empty);
    

        private void SetWeekStart(DateTime anyDayInWeek)
        {
            int diff = (7 + (int)anyDayInWeek.DayOfWeek - (int)DayOfWeek.Monday) % 7;
            _weekStart = anyDayInWeek.Date.AddDays(-diff);
        }

        private void UpdateDateRangeLabel() => lblCurrentDateRange.Text = $"{_weekStart:MMM d} - {_weekStart.AddDays(6):MMM d}";

        private void scrollPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}