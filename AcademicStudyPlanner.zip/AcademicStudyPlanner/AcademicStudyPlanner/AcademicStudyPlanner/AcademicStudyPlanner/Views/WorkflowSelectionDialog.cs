using System;
using System.Windows.Forms;
using AcademicStudyPlanner.BusinessLogic;

namespace AcademicStudyPlanner.Views
{
    public partial class WorkflowSelectionDialog : Form
    {
        private RadioButton rbCombined;
        private RadioButton rbSemesterOnly;
        private RadioButton rbAssignmentOnly;
        private Button btnOK;
        private Button btnCancel;

        public PlanningWorkflow SelectedWorkflow { get; private set; } = PlanningWorkflow.Combined;

        public WorkflowSelectionDialog()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            rbCombined = new RadioButton();
            rbSemesterOnly = new RadioButton();
            rbAssignmentOnly = new RadioButton();
            btnOK = new Button();
            btnCancel = new Button();
            SuspendLayout();

            // rbCombined
            rbCombined.AutoSize = true;
            rbCombined.Checked = true;
            rbCombined.Location = new System.Drawing.Point(20, 20);
            rbCombined.Name = "rbCombined";
            rbCombined.Size = new System.Drawing.Size(200, 19);
            rbCombined.TabIndex = 0;
            rbCombined.TabStop = true;
            rbCombined.Text = "Combined Planning (Semester + Assignments)";
            rbCombined.UseVisualStyleBackColor = true;

            // rbSemesterOnly
            rbSemesterOnly.AutoSize = true;
            rbSemesterOnly.Location = new System.Drawing.Point(20, 50);
            rbSemesterOnly.Name = "rbSemesterOnly";
            rbSemesterOnly.Size = new System.Drawing.Size(200, 19);
            rbSemesterOnly.TabIndex = 1;
            rbSemesterOnly.Text = "Semester-Only Planning";
            rbSemesterOnly.UseVisualStyleBackColor = true;

            // rbAssignmentOnly
            rbAssignmentOnly.AutoSize = true;
            rbAssignmentOnly.Location = new System.Drawing.Point(20, 80);
            rbAssignmentOnly.Name = "rbAssignmentOnly";
            rbAssignmentOnly.Size = new System.Drawing.Size(200, 19);
            rbAssignmentOnly.TabIndex = 2;
            rbAssignmentOnly.Text = "Assignment-Only Planning";
            rbAssignmentOnly.UseVisualStyleBackColor = true;

            // btnOK
            btnOK.DialogResult = DialogResult.OK;
            btnOK.Location = new System.Drawing.Point(150, 120);
            btnOK.Name = "btnOK";
            btnOK.Size = new System.Drawing.Size(75, 23);
            btnOK.TabIndex = 3;
            btnOK.Text = "OK";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += BtnOK_Click;

            // btnCancel
            btnCancel.DialogResult = DialogResult.Cancel;
            btnCancel.Location = new System.Drawing.Point(230, 120);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new System.Drawing.Size(75, 23);
            btnCancel.TabIndex = 4;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;

            // WorkflowSelectionDialog
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(320, 160);
            Controls.Add(rbCombined);
            Controls.Add(rbSemesterOnly);
            Controls.Add(rbAssignmentOnly);
            Controls.Add(btnOK);
            Controls.Add(btnCancel);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "WorkflowSelectionDialog";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Select Planning Workflow";
            ResumeLayout(false);
            PerformLayout();
        }

        private void BtnOK_Click(object? sender, EventArgs e)
        {
            if (rbCombined.Checked)
                SelectedWorkflow = PlanningWorkflow.Combined;
            else if (rbSemesterOnly.Checked)
                SelectedWorkflow = PlanningWorkflow.SemesterOnly;
            else if (rbAssignmentOnly.Checked)
                SelectedWorkflow = PlanningWorkflow.AssignmentOnly;
        }
    }
}



