using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using AcademicStudyPlanner.Models;

namespace AcademicStudyPlanner.Views
{
    public partial class CustomGradeScaleForm : Form
    {
        private DataGridView _dgvGrades;
        private Button _btnAdd;
        private Button _btnRemove;
        private Button _btnOK;
        private Button _btnCancel;
        private Button _btnReset;
        private GradeScale _gradeScale;

        public GradeScale GradeScale { get; private set; }

        public CustomGradeScaleForm(GradeScale? existingScale = null)
        {
            _gradeScale = existingScale ?? new GradeScale { Items = new List<GradeScaleItem>() };
            InitializeComponent();
            LoadGradeScale();
        }

        private void InitializeComponent()
        {
            Text = "Custom Grade Scale";
            Size = new Size(600, 500);
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;

            var mainPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(10)
            };
            mainPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));

            // Instructions label
            var lblInstructions = new Label
            {
                Text = "Define your custom grade scale. Add rows for each grade with letter, percentage range, and grade points.",
                Dock = DockStyle.Fill,
                AutoSize = true
            };
            mainPanel.Controls.Add(lblInstructions, 0, 0);

            // DataGridView for grade scale items
            _dgvGrades = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = true,
                AllowUserToDeleteRows = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                Margin = new Padding(0, 5, 0, 5)
            };

            _dgvGrades.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Letter",
                HeaderText = "Letter Grade",
                Width = 120
            });

            _dgvGrades.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "MinPercent",
                HeaderText = "Min %",
                Width = 80
            });

            _dgvGrades.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "MaxPercent",
                HeaderText = "Max %",
                Width = 80
            });

            _dgvGrades.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "GradePoints",
                HeaderText = "Grade Points",
                Width = 100
            });

            mainPanel.Controls.Add(_dgvGrades, 0, 1);

            // Button panel
            var buttonPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = true
            };

            _btnAdd = new Button
            {
                Text = "Add Row",
                Size = new Size(100, 30),
                Margin = new Padding(5)
            };
            _btnAdd.Click += BtnAdd_Click;

            _btnRemove = new Button
            {
                Text = "Remove Row",
                Size = new Size(100, 30),
                Margin = new Padding(5)
            };
            _btnRemove.Click += BtnRemove_Click;

            _btnReset = new Button
            {
                Text = "Reset to Preset",
                Size = new Size(120, 30),
                Margin = new Padding(5)
            };
            _btnReset.Click += BtnReset_Click;

            buttonPanel.Controls.Add(_btnAdd);
            buttonPanel.Controls.Add(_btnRemove);
            buttonPanel.Controls.Add(_btnReset);
            mainPanel.Controls.Add(buttonPanel, 0, 2);

            // OK/Cancel panel
            var okCancelPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                AutoSize = true
            };

            _btnOK = new Button
            {
                Text = "OK",
                Size = new Size(80, 30),
                Margin = new Padding(5),
                DialogResult = DialogResult.OK
            };
            _btnOK.Click += BtnOK_Click;

            _btnCancel = new Button
            {
                Text = "Cancel",
                Size = new Size(80, 30),
                Margin = new Padding(5),
                DialogResult = DialogResult.Cancel
            };

            okCancelPanel.Controls.Add(_btnOK);
            okCancelPanel.Controls.Add(_btnCancel);
            mainPanel.Controls.Add(okCancelPanel, 0, 3);

            Controls.Add(mainPanel);
        }

        private void LoadGradeScale()
        {
            _dgvGrades.Rows.Clear();
            if (_gradeScale.Items != null)
            {
                foreach (var item in _gradeScale.Items.OrderByDescending(i => i.GradePoints))
                {
                    _dgvGrades.Rows.Add(item.Letter, item.MinPercent, item.MaxPercent, item.GradePoints);
                }
            }

            // Add empty row for new entries
            if (_dgvGrades.Rows.Count == 0)
            {
                _dgvGrades.Rows.Add();
            }
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            _dgvGrades.Rows.Add();
            _dgvGrades.FirstDisplayedScrollingRowIndex = _dgvGrades.Rows.Count - 1;
        }

        private void BtnRemove_Click(object? sender, EventArgs e)
        {
            if (_dgvGrades.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in _dgvGrades.SelectedRows)
                {
                    if (!row.IsNewRow)
                    {
                        _dgvGrades.Rows.Remove(row);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to remove.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnReset_Click(object? sender, EventArgs e)
        {
            var result = MessageBox.Show(
                "Reset to the preset university-standard grade scale? This will replace all current entries.",
                "Reset Grade Scale",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                _gradeScale = GradeScale.GetPreset();
                LoadGradeScale();
            }
        }

        private void BtnOK_Click(object? sender, EventArgs e)
        {
            if (!ValidateAndSave())
            {
                DialogResult = DialogResult.None;
            }
        }

        private bool ValidateAndSave()
        {
            var items = new List<GradeScaleItem>();

            foreach (DataGridViewRow row in _dgvGrades.Rows)
            {
                if (row.IsNewRow) continue;

                var letterCell = row.Cells["Letter"];
                var minPercentCell = row.Cells["MinPercent"];
                var maxPercentCell = row.Cells["MaxPercent"];
                var gradePointsCell = row.Cells["GradePoints"];

                if (letterCell.Value == null || string.IsNullOrWhiteSpace(letterCell.Value.ToString()))
                    continue; // Skip empty rows

                if (minPercentCell.Value == null || maxPercentCell.Value == null || gradePointsCell.Value == null)
                {
                    MessageBox.Show($"Row {row.Index + 1}: Please fill in all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (!int.TryParse(minPercentCell.Value.ToString(), out int minPercent) ||
                    !int.TryParse(maxPercentCell.Value.ToString(), out int maxPercent) ||
                    !double.TryParse(gradePointsCell.Value.ToString(), out double gradePoints))
                {
                    MessageBox.Show($"Row {row.Index + 1}: Please enter valid numbers.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                items.Add(new GradeScaleItem
                {
                    Letter = letterCell.Value.ToString() ?? string.Empty,
                    MinPercent = minPercent,
                    MaxPercent = maxPercent,
                    GradePoints = gradePoints
                });
            }

            if (items.Count == 0)
            {
                MessageBox.Show("Please add at least one grade scale item.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            _gradeScale.Items = items;
            if (!_gradeScale.Validate(out string errorMessage))
            {
                MessageBox.Show($"Invalid grade scale: {errorMessage}", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            GradeScale = _gradeScale;
            return true;
        }
    }
}

