﻿namespace AcademicStudyPlanner.Views
{

    partial class SemesterAnalysis
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        /// 
        private void InitializeComponent()
        {
            flowLayoutPanel1 = new FlowLayoutPanel();
            label1 = new Label();
            label2 = new Label();
            numericUpDown1 = new NumericUpDown();
            label3 = new Label();
            numericUpDown2 = new NumericUpDown();
            label4 = new Label();
            textBox1 = new TextBox();
            flowLayoutPanel2 = new FlowLayoutPanel();
            label5 = new Label();
            label6 = new Label();
            textBox2 = new TextBox();
            flowLayoutPanel3 = new FlowLayoutPanel();
            flowLayoutPanel5 = new FlowLayoutPanel();
            groupBox1 = new GroupBox();
            button1 = new Button();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            flowLayoutPanel4 = new FlowLayoutPanel();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label10 = new Label();
            dateTimePicker2 = new DateTimePicker();
            label11 = new Label();
            comboBox1 = new ComboBox();
            button2 = new Button();
            label12 = new Label();
            button3 = new Button();
            button4 = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            button5 = new Button();
            flowLayoutPanel7 = new FlowLayoutPanel();
            label15 = new Label();
            flowLayoutPanel8 = new FlowLayoutPanel();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            panel1 = new Panel();
            flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            flowLayoutPanel2.SuspendLayout();
            flowLayoutPanel5.SuspendLayout();
            groupBox1.SuspendLayout();
            flowLayoutPanel4.SuspendLayout();
            flowLayoutPanel7.SuspendLayout();
            flowLayoutPanel8.SuspendLayout();
            SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoSize = true;
            flowLayoutPanel1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            flowLayoutPanel1.Controls.Add(label1);
            flowLayoutPanel1.Controls.Add(label2);
            flowLayoutPanel1.Controls.Add(numericUpDown1);
            flowLayoutPanel1.Controls.Add(label3);
            flowLayoutPanel1.Controls.Add(numericUpDown2);
            flowLayoutPanel1.Controls.Add(label4);
            flowLayoutPanel1.Controls.Add(textBox1);
            flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel1.Location = new Point(9, 34);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Padding = new Padding(10);
            flowLayoutPanel1.Size = new Size(198, 197);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(13, 10);
            label1.Name = "label1";
            label1.Size = new Size(101, 15);
            label1.TabIndex = 0;
            label1.Text = "Academic Profile";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 30);
            label2.Margin = new Padding(3, 5, 3, 5);
            label2.Name = "label2";
            label2.Size = new Size(172, 15);
            label2.TabIndex = 1;
            label2.Text = "Total Credit Hours for the Year :";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(13, 53);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(167, 23);
            numericUpDown1.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 84);
            label3.Margin = new Padding(3, 5, 3, 5);
            label3.Name = "label3";
            label3.Size = new Size(167, 15);
            label3.TabIndex = 3;
            label3.Text = "Past Completed Credit Hours :";
            // 
            // numericUpDown2
            // 
            numericUpDown2.Location = new Point(13, 107);
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new Size(167, 23);
            numericUpDown2.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 138);
            label4.Margin = new Padding(3, 5, 3, 5);
            label4.Name = "label4";
            label4.Size = new Size(92, 15);
            label4.TabIndex = 5;
            label4.Text = "Past GPA Score :";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(13, 161);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(167, 23);
            textBox1.TabIndex = 6;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.AutoSize = true;
            flowLayoutPanel2.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            flowLayoutPanel2.Controls.Add(label5);
            flowLayoutPanel2.Controls.Add(label6);
            flowLayoutPanel2.Controls.Add(textBox2);
            flowLayoutPanel2.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel2.Location = new Point(9, 237);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(146, 79);
            flowLayoutPanel2.TabIndex = 0;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(3, 5);
            label5.Margin = new Padding(3, 5, 3, 5);
            label5.Name = "label5";
            label5.Size = new Size(75, 15);
            label5.TabIndex = 0;
            label5.Text = "Target GPA :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(3, 30);
            label6.Margin = new Padding(3, 5, 3, 5);
            label6.Name = "label6";
            label6.Size = new Size(99, 15);
            label6.TabIndex = 1;
            label6.Text = "Target Final GPA :";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(3, 53);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(140, 23);
            textBox2.TabIndex = 1;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.AutoScroll = true;
            flowLayoutPanel3.AutoSize = true;
            flowLayoutPanel3.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            flowLayoutPanel3.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel3.Location = new Point(2, 330);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(0, 0);
            flowLayoutPanel3.TabIndex = 2;
            // 
            // flowLayoutPanel5
            // 
            flowLayoutPanel5.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            flowLayoutPanel5.Controls.Add(groupBox1);
            flowLayoutPanel5.Location = new Point(5, 322);
            flowLayoutPanel5.Name = "flowLayoutPanel5";
            flowLayoutPanel5.Padding = new Padding(2, 20, 2, 20);
            flowLayoutPanel5.Size = new Size(355, 305);
            flowLayoutPanel5.TabIndex = 6;
            // 
            // groupBox1
            // 
            groupBox1.AutoSize = true;
            groupBox1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(5, 23);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(270, 252);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Grade Scale :";
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button1.Location = new Point(104, 203);
            button1.Name = "button1";
            button1.Size = new Size(148, 27);
            button1.TabIndex = 2;
            button1.Text = "Custom Grade Scale Settings";
            button1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(3, 178);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(142, 19);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "Custom Grade Scale :";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(3, 19);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(136, 19);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "Preset Grade Scale :";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.AutoSize = true;
            flowLayoutPanel4.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            flowLayoutPanel4.Controls.Add(label7);
            flowLayoutPanel4.Controls.Add(label8);
            flowLayoutPanel4.Controls.Add(label9);
            flowLayoutPanel4.Controls.Add(dateTimePicker1);
            flowLayoutPanel4.Controls.Add(label10);
            flowLayoutPanel4.Controls.Add(dateTimePicker2);
            flowLayoutPanel4.Controls.Add(label11);
            flowLayoutPanel4.Controls.Add(comboBox1);
            flowLayoutPanel4.Controls.Add(button2);
            flowLayoutPanel4.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel4.Location = new Point(678, 34);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(228, 241);
            flowLayoutPanel4.TabIndex = 3;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(3, 5);
            label7.Margin = new Padding(3, 5, 3, 5);
            label7.Name = "label7";
            label7.Size = new Size(102, 15);
            label7.TabIndex = 0;
            label7.Text = "Analysis Settings ";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(30, 35);
            label8.Margin = new Padding(30, 10, 10, 10);
            label8.Name = "label8";
            label8.Size = new Size(172, 15);
            label8.TabIndex = 1;
            label8.Text = "Semester Start and Finish Date :";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(3, 60);
            label9.Name = "label9";
            label9.Size = new Size(64, 15);
            label9.TabIndex = 2;
            label9.Text = "Start Date :";
            label9.Click += label9_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(3, 78);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(222, 23);
            dateTimePicker1.TabIndex = 3;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(3, 109);
            label10.Margin = new Padding(3, 5, 3, 5);
            label10.Name = "label10";
            label10.Size = new Size(60, 15);
            label10.TabIndex = 4;
            label10.Text = "End Date :";
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(3, 132);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(222, 23);
            dateTimePicker2.TabIndex = 4;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(3, 163);
            label11.Margin = new Padding(3, 5, 3, 5);
            label11.Name = "label11";
            label11.Size = new Size(130, 15);
            label11.TabIndex = 5;
            label11.Text = "Select Analysis Option :";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Equal Effort", "Credit Weight", "Strong/Weak" });
            comboBox1.Location = new Point(3, 186);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(222, 23);
            comboBox1.TabIndex = 4;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Top;
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(59, 215);
            button2.Name = "button2";
            button2.Size = new Size(110, 23);
            button2.TabIndex = 6;
            button2.Text = "Run Analysis";
            button2.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(45, 9);
            label12.Name = "label12";
            label12.Size = new Size(119, 17);
            label12.TabIndex = 3;
            label12.Text = "Semester Analysis";
            label12.Click += label12_Click;
            // 
            // button3
            // 
            button3.AutoSize = true;
            button3.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(70, 641);
            button3.Name = "button3";
            button3.Size = new Size(96, 25);
            button3.TabIndex = 4;
            button3.Text = "Generate Plan";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button4.AutoSize = true;
            button4.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(201, 641);
            button4.Name = "button4";
            button4.Size = new Size(147, 25);
            button4.TabIndex = 5;
            button4.Text = "Proceed To Assignment";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button5.Location = new Point(8, 62);
            button5.Name = "button5";
            button5.Size = new Size(312, 23);
            button5.TabIndex = 8;
            button5.Text = "+ Add Course";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // flowLayoutPanel7
            // 
            flowLayoutPanel7.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            flowLayoutPanel7.AutoScroll = true;
            flowLayoutPanel7.Controls.Add(label15);
            flowLayoutPanel7.Controls.Add(flowLayoutPanel8);
            flowLayoutPanel7.Controls.Add(button5);
            flowLayoutPanel7.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel7.Location = new Point(215, 32);
            flowLayoutPanel7.Margin = new Padding(5);
            flowLayoutPanel7.Name = "flowLayoutPanel7";
            flowLayoutPanel7.Padding = new Padding(5);
            flowLayoutPanel7.Size = new Size(421, 211);
            flowLayoutPanel7.TabIndex = 9;
            flowLayoutPanel7.WrapContents = false;
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label15.AutoSize = true;
            label15.Location = new Point(8, 5);
            label15.Name = "label15";
            label15.Size = new Size(312, 15);
            label15.TabIndex = 0;
            label15.Text = "Course Management";
            // 
            // flowLayoutPanel8
            // 
            flowLayoutPanel8.Controls.Add(label16);
            flowLayoutPanel8.Controls.Add(label17);
            flowLayoutPanel8.Controls.Add(label18);
            flowLayoutPanel8.Location = new Point(8, 23);
            flowLayoutPanel8.Name = "flowLayoutPanel8";
            flowLayoutPanel8.Size = new Size(312, 33);
            flowLayoutPanel8.TabIndex = 1;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(10, 3);
            label16.Margin = new Padding(10, 3, 10, 3);
            label16.Name = "label16";
            label16.Size = new Size(82, 15);
            label16.TabIndex = 0;
            label16.Text = "Course Name ";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(112, 3);
            label17.Margin = new Padding(10, 3, 10, 3);
            label17.Name = "label17";
            label17.Size = new Size(51, 15);
            label17.TabIndex = 1;
            label17.Text = "Cr-Hour";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(183, 3);
            label18.Margin = new Padding(10, 3, 10, 3);
            label18.Name = "label18";
            label18.Size = new Size(109, 15);
            label18.TabIndex = 2;
            label18.Text = "Strength/Weakness";
            // 
            // panel1
            // 
            panel1.Location = new Point(381, 322);
            panel1.Name = "panel1";
            panel1.Size = new Size(393, 334);
            panel1.TabIndex = 2;
            // 
            // SemesterAnalysis
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(930, 652);
            Controls.Add(flowLayoutPanel5);
            Controls.Add(panel1);
            Controls.Add(flowLayoutPanel7);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(label12);
            Controls.Add(flowLayoutPanel4);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(flowLayoutPanel3);
            Name = "SemesterAnalysis";
            Text = "Form1";
            Load += Form1_Load;
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            flowLayoutPanel2.ResumeLayout(false);
            flowLayoutPanel2.PerformLayout();
            flowLayoutPanel5.ResumeLayout(false);
            flowLayoutPanel5.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            flowLayoutPanel4.ResumeLayout(false);
            flowLayoutPanel4.PerformLayout();
            flowLayoutPanel7.ResumeLayout(false);
            flowLayoutPanel7.PerformLayout();
            flowLayoutPanel8.ResumeLayout(false);
            flowLayoutPanel8.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private FlowLayoutPanel flowLayoutPanel1;
        private Label label1;
        private FlowLayoutPanel flowLayoutPanel2;
        private Label label2;
        private NumericUpDown numericUpDown1;
        private Label label3;
        private NumericUpDown numericUpDown2;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textBox2;
        private FlowLayoutPanel flowLayoutPanel3;
        private GroupBox groupBox1;
        private Button button1;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private FlowLayoutPanel flowLayoutPanel4;
        private Label label7;
        private Label label8;
        private Label label9;
        private DateTimePicker dateTimePicker1;
        private Label label10;
        private DateTimePicker dateTimePicker2;
        private Label label11;
        private ComboBox comboBox1;
        private Button button2;
        private Label label12;
        private Button button3;
        private Button button4;
        private FlowLayoutPanel flowLayoutPanel5;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Button button5;
        private FlowLayoutPanel flowLayoutPanel7;
        private Label label15;
        private FlowLayoutPanel flowLayoutPanel8;
        private Label label16;
        private Label label17;
        private Label label18;
        private TextBox textBox1;
        private Panel panel1;

        // Place designer-added event handlers inside the partial class so they are valid members.
        // These were previously declared outside the class/namespace (top-level), causing CS8801.
        private void label1_Click(object sender, EventArgs e)
        {
            // You can add custom logic here if needed
        }

        private void label12_Click(object sender, EventArgs e)
        {
            // You can add custom logic here if needed
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // You can add custom logic here if needed
        }

        // Add this missing event handler to fix CS0103:
        private void label9_Click(object sender, EventArgs e)
        {
            // You can add custom logic here if needed
        }

        // Add this event handler inside the SemesterAnalysis partial class
        private void Form1_Load(object sender, EventArgs e)
        {
            // You can add custom logic here if needed
        }
    }
}
