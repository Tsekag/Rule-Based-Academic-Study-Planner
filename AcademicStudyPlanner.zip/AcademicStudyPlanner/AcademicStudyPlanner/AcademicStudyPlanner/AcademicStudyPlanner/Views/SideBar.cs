﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AcademicStudyPlanner.Views;

namespace AcademicStudyPlanner.Views
{
    public partial class SideBar : Form
    {
        public SideBar()
        {
            InitializeComponent();
        }
        private void LoadFormInPanel(Form form)
        {
            panel1.SuspendLayout();       // Stop flicker while loading

            panel1.Controls.Clear();

            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.AutoScaleMode = AutoScaleMode.Dpi;   // Makes resizing crisp
            form.Dock = DockStyle.Fill;

            panel1.Controls.Add(form);
            form.Show();

            panel1.ResumeLayout();
        }

        // inside your Main Form
        private void ShowCalendarView()
        {
            var calendarView = new AcademicStudyPlanner.Views.plan.CalendarView
            {
                Dock = DockStyle.Fill
            };

            panel1.Controls.Clear();
            panel1.Controls.Add(calendarView);
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadFormInPanel(new SemesterAnalysis());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadFormInPanel(new AssignmentPlanner());
        }

        private void button3_Click(object sender, EventArgs e)
        {
             LoadFormInPanel(new PlannerEngine());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadFormInPanel(new AvailabilityManager());
        }

        private void SideBar_Load(object sender, EventArgs e)
        {

        }

        
    }
}
