﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using AcademicStudyPlanner.Data;
using AcademicStudyPlanner.Models;
using AcademicStudyPlanner.BusinessLogic;
using AcademicStudyPlanner.Services;

namespace AcademicStudyPlanner.Views
{
    public partial class AssignmentPlanner : Form
    {
        private readonly DataRepository _dataRepository;
        private readonly ReminderService _reminderService;
        private List<Assignment> _assignments = new();
        private DataGridView? _dgvAssignments;
        private Button? _btnAdd;
        private Button? _btnEdit;
        private Button? _btnDelete;
        private Button? _btnComplete;
        private Button? _btnGeneratePlan;
        private Assignment? _editingAssignment;

        public AssignmentPlanner()
        {
            InitializeComponent();
            _dataRepository = new DataRepository();
            _reminderService = new ReminderService();
            InitializeAssignmentList();
            LoadAssignments();
            LoadCourses();
            UpdateReminders();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
            _reminderService?.Dispose();
        }

        private void InitializeAssignmentList()
        {
            // Create DataGridView for assignments if it doesn't exist
            _dgvAssignments = this.Controls.Find("dgvAssignments", true).FirstOrDefault() as DataGridView;
            
            if (_dgvAssignments == null)
            {
                _dgvAssignments = new DataGridView
                {
                    Name = "dgvAssignments",
                    Dock = DockStyle.Fill,
                    Location = new Point(262, 220),
                    Size = new Size(520, 200),
                    Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                    AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                    ReadOnly = true,
                    MultiSelect = false
                };
                this.Controls.Add(_dgvAssignments);
                _dgvAssignments.CellDoubleClick += DgvAssignments_CellDoubleClick;
            }

            // Initialize columns
            _dgvAssignments.Columns.Clear();
            _dgvAssignments.Columns.Add("Title", "Title");
            _dgvAssignments.Columns.Add("Course", "Course");
            _dgvAssignments.Columns.Add("Duration", "Duration (hrs)");
            _dgvAssignments.Columns.Add("DueDate", "Due Date");
            _dgvAssignments.Columns.Add("Status", "Status");
            _dgvAssignments.Columns.Add("Id", "Id");
            _dgvAssignments.Columns["Id"].Visible = false;

            // Add action buttons
            var buttonPanel = new FlowLayoutPanel
            {
                Location = new Point(262, 420),
                Size = new Size(520, 30),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                FlowDirection = FlowDirection.LeftToRight
            };

            _btnAdd = new Button { Text = "Add", Size = new Size(80, 25), Margin = new Padding(5) };
            _btnAdd.Click += BtnAdd_Click;
            buttonPanel.Controls.Add(_btnAdd);

            _btnEdit = new Button { Text = "Edit", Size = new Size(80, 25), Margin = new Padding(5) };
            _btnEdit.Click += BtnEdit_Click;
            buttonPanel.Controls.Add(_btnEdit);

            _btnComplete = new Button { Text = "Mark Complete", Size = new Size(120, 25), Margin = new Padding(5) };
            _btnComplete.Click += BtnComplete_Click;
            buttonPanel.Controls.Add(_btnComplete);

            _btnDelete = new Button { Text = "Delete", Size = new Size(80, 25), Margin = new Padding(5), BackColor = Color.Red, ForeColor = Color.White };
            _btnDelete.Click += BtnDelete_Click;
            buttonPanel.Controls.Add(_btnDelete);

            _btnGeneratePlan = new Button { Text = "Generate Plan", Size = new Size(120, 25), Margin = new Padding(5), Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
            _btnGeneratePlan.Click += BtnGeneratePlan_Click;
            buttonPanel.Controls.Add(_btnGeneratePlan);

            this.Controls.Add(buttonPanel);

            // Update existing button1 to be "Add Assignment"
            if (button1 != null)
            {
                button1.Text = "Add Assignment";
            }
        }

        private void AssignmentPlanner_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Value = DateTime.Today;
            dateTimePicker2.Value = DateTime.Today.AddDays(7);
            numericUpDown1.Minimum = 0.5m;
            numericUpDown1.Maximum = 100;
            numericUpDown1.Value = 2;
            numericUpDown1.DecimalPlaces = 1;
            numericUpDown1.Increment = 0.5m;
            RefreshAssignmentList();
        }

        private void LoadCourses()
        {
            var courses = _dataRepository.LoadCourses();
            comboBox1.Items.Clear();
            comboBox1.Items.AddRange(courses.Select(c => c.Name).ToArray());
        }

        private void LoadAssignments()
        {
            _assignments.Clear();
            _assignments.AddRange(_dataRepository.LoadAssignments());
        }

        private void UpdateReminders()
        {
            _reminderService.UpdateReminders(_assignments);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BtnAdd_Click(sender, e);
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            if (_editingAssignment != null)
            {
                // If editing, update existing
                UpdateAssignment(_editingAssignment);
                _editingAssignment = null;
                button1.Text = "Add Assignment";
            }
            else
            {
                // Add new assignment
                if (!ValidateInput())
                    return;

                var assignment = new Assignment
                {
                    Title = textBox1.Text,
                    CourseName = comboBox1.SelectedItem?.ToString() ?? comboBox1.Text,
                    EstimatedDuration = TimeSpan.FromHours((double)numericUpDown1.Value),
                    DueDate = dateTimePicker2.Value,
                    StartDate = dateTimePicker1.Value
                };

                _assignments.Add(assignment);
                _dataRepository.SaveAssignments(_assignments);
                _reminderService.RegisterReminder(assignment);
                RefreshAssignmentList();
                ClearForm();
                MessageBox.Show("Assignment added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnEdit_Click(object? sender, EventArgs e)
        {
            if (_dgvAssignments?.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an assignment to edit.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var selectedRow = _dgvAssignments.SelectedRows[0];
            var assignmentId = selectedRow.Cells["Id"].Value?.ToString();
            _editingAssignment = _assignments.FirstOrDefault(a => a.Id == assignmentId);

            if (_editingAssignment != null)
            {
                // Load assignment data into form
                textBox1.Text = _editingAssignment.Title;
                comboBox1.Text = _editingAssignment.CourseName;
                numericUpDown1.Value = (decimal)_editingAssignment.EstimatedDuration.TotalHours;
                dateTimePicker1.Value = _editingAssignment.StartDate;
                dateTimePicker2.Value = _editingAssignment.DueDate;
                button1.Text = "Update Assignment";
            }
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_dgvAssignments?.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an assignment to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var result = MessageBox.Show(
                "Are you sure you want to delete this assignment?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                var selectedRow = _dgvAssignments.SelectedRows[0];
                var assignmentId = selectedRow.Cells["Id"].Value?.ToString();
                var assignment = _assignments.FirstOrDefault(a => a.Id == assignmentId);

                if (assignment != null)
                {
                    _reminderService.RemoveReminder(assignment.Id);
                    _assignments.Remove(assignment);
                    _dataRepository.SaveAssignments(_assignments);
                    RefreshAssignmentList();
                    ClearForm();
                }
            }
        }

        private void BtnComplete_Click(object? sender, EventArgs e)
        {
            if (_dgvAssignments?.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an assignment to mark as complete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var selectedRow = _dgvAssignments.SelectedRows[0];
            var assignmentId = selectedRow.Cells["Id"].Value?.ToString();
            var assignment = _assignments.FirstOrDefault(a => a.Id == assignmentId);

            if (assignment != null)
            {
                assignment.IsCompleted = !assignment.IsCompleted;
                _dataRepository.SaveAssignments(_assignments);
                if (assignment.IsCompleted)
                {
                    _reminderService.RemoveReminder(assignment.Id);
                }
                else
                {
                    _reminderService.RegisterReminder(assignment);
                }
                RefreshAssignmentList();
            }
        }

        private void BtnGeneratePlan_Click(object? sender, EventArgs e)
        {
            if (_assignments.Count == 0)
            {
                MessageBox.Show("Please add at least one assignment before generating a plan.", "No Assignments", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            ShowAvailabilityAndGeneratePlan();
        }

        private void DgvAssignments_CellDoubleClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                BtnEdit_Click(sender, e);
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Please enter an assignment title.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (comboBox1.SelectedItem == null && string.IsNullOrWhiteSpace(comboBox1.Text))
            {
                MessageBox.Show("Please select or enter a course name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (dateTimePicker2.Value < dateTimePicker1.Value)
            {
                MessageBox.Show("Due date must be after start date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void UpdateAssignment(Assignment assignment)
        {
            if (!ValidateInput())
                return;

            assignment.Title = textBox1.Text;
            assignment.CourseName = comboBox1.SelectedItem?.ToString() ?? comboBox1.Text;
            assignment.EstimatedDuration = TimeSpan.FromHours((double)numericUpDown1.Value);
            assignment.DueDate = dateTimePicker2.Value;
            assignment.StartDate = dateTimePicker1.Value;

            _dataRepository.SaveAssignments(_assignments);
            _reminderService.RegisterReminder(assignment);
            RefreshAssignmentList();
            ClearForm();
            MessageBox.Show("Assignment updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void RefreshAssignmentList()
        {
            if (_dgvAssignments == null) return;

            _dgvAssignments.Rows.Clear();
            foreach (var assignment in _assignments)
            {
                _dgvAssignments.Rows.Add(
                    assignment.Title,
                    assignment.CourseName,
                    assignment.EstimatedDuration.TotalHours.ToString("F1"),
                    assignment.DueDate.ToString("MM/dd/yyyy"),
                    assignment.IsCompleted ? "Completed" : "Pending",
                    assignment.Id
                );
            }
        }

        private void ClearForm()
        {
            textBox1.Clear();
            comboBox1.SelectedIndex = -1;
            numericUpDown1.Value = 2;
            dateTimePicker1.Value = DateTime.Today;
            dateTimePicker2.Value = DateTime.Today.AddDays(7);
            _editingAssignment = null;
            if (button1 != null)
                button1.Text = "Add Assignment";
        }

        private void ShowAvailabilityAndGeneratePlan()
        {
            // Check if availability is set
            var availability = _dataRepository.LoadAvailability();
            if (availability.TotalHoursPerWeek == 0)
            {
                var result = MessageBox.Show(
                    "No availability has been set. Would you like to set your availability now?",
                    "Availability Required",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    var availabilityForm = new AvailabilityManager();
                    if (availabilityForm.ShowDialog() == DialogResult.OK)
                    {
                        availability = availabilityForm.GetAvailability();
                        _dataRepository.SaveAvailability(availability);
                    }
                    else
                    {
                        return; // User cancelled
                    }
                }
                else
                {
                    MessageBox.Show("Cannot generate plan without availability settings.", "Insufficient Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            // Show workflow selection
            var workflowForm = new WorkflowSelectionDialog();
            if (workflowForm.ShowDialog() == DialogResult.OK)
            {
                var workflow = workflowForm.SelectedWorkflow;
                
                // Open PlannerEngine with the selected workflow
                var planner = new PlannerEngine();
                planner.GeneratePlan(workflow);
                
                // Switch to planner view (assuming parent can handle this)
                if (this.Parent is Panel parentPanel)
                {
                    parentPanel.Controls.Clear();
                    planner.TopLevel = false;
                    planner.FormBorderStyle = FormBorderStyle.None;
                    planner.Dock = DockStyle.Fill;
                    parentPanel.Controls.Add(planner);
                    planner.Show();
                }
            }
        }

        public List<Assignment> GetAssignments()
        {
            return _assignments;
        }

        // Event handlers referenced by Designer (can be empty if not needed)
        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void label2_Click(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void label3_Click(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void label5_Click(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void label6_Click(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void flowLayoutPanel3_Paint(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void label7_Click(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            // Empty handler - required by Designer
        }
    }
}
