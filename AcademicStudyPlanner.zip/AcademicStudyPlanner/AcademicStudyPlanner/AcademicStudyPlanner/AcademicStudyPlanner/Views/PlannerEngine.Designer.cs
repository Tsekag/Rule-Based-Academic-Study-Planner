﻿namespace AcademicStudyPlanner.Views
{
    partial class PlannerEngine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.FlowLayoutPanel navButtonsPanel;
        private System.Windows.Forms.Button btnProceedToAssignment;
        private System.Windows.Forms.Button btnGeneratePlanOnly;
        private System.Windows.Forms.Button btnNext;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            headerPanel = new System.Windows.Forms.Panel();
            navButtonsPanel = new System.Windows.Forms.FlowLayoutPanel();
            btnProceedToAssignment = new System.Windows.Forms.Button();
            btnGeneratePlanOnly = new System.Windows.Forms.Button();
            btnNext = new System.Windows.Forms.Button();

            SuspendLayout();
            // 
            // headerPanel
            // 
            headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            headerPanel.Height = 52;
            headerPanel.Padding = new System.Windows.Forms.Padding(8);
            headerPanel.BackColor = System.Drawing.Color.WhiteSmoke;
            headerPanel.Controls.Add(navButtonsPanel);
            // 
            // navButtonsPanel
            // 
            navButtonsPanel.Dock = System.Windows.Forms.DockStyle.Right;
            navButtonsPanel.FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight;
            navButtonsPanel.WrapContents = false;
            navButtonsPanel.AutoSize = true;
            navButtonsPanel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            navButtonsPanel.Controls.Add(btnProceedToAssignment);
            navButtonsPanel.Controls.Add(btnGeneratePlanOnly);
            navButtonsPanel.Controls.Add(btnNext);
            // 
            // btnProceedToAssignment
            // 
            btnProceedToAssignment.Text = "Proceed to Assignment";
            btnProceedToAssignment.AutoSize = true;
            btnProceedToAssignment.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            btnProceedToAssignment.Click += BtnProceedToAssignment_Click;
            // 
            // btnGeneratePlanOnly
            // 
            btnGeneratePlanOnly.Text = "Generate Plan Only";
            btnGeneratePlanOnly.AutoSize = true;
            btnGeneratePlanOnly.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            btnGeneratePlanOnly.Click += BtnGeneratePlanOnly_Click;
            // 
            // btnNext
            // 
            btnNext.Text = "Next";
            btnNext.AutoSize = true;
            btnNext.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            btnNext.Click += BtnNext_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            tableLayoutPanel1.Location = new System.Drawing.Point(0, 52);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.Size = new System.Drawing.Size(838, 565);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // PlannerEngine
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(838, 565);
            Name = "PlannerEngine";
            Text = "PlannerEngine";
            Controls.Add(tableLayoutPanel1);
            Controls.Add(headerPanel);
            Load += PlannerEngine_Load;
            ResumeLayout(false);
        }

        #endregion
    }
}