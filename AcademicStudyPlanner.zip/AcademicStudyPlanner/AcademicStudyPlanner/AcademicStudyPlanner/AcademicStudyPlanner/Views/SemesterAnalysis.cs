﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using AcademicStudyPlanner.Models;
using AcademicStudyPlanner.BusinessLogic;
using AcademicStudyPlanner.Data;
using AcademicStudyPlanner.Services;

namespace AcademicStudyPlanner.Views
{
    public partial class SemesterAnalysis : Form
    {
        // Add these fields to the SemesterAnalysis class, before the constructor
        private FlowLayoutPanel flowLayoutPanel6;
        private FlowLayoutPanel flowLayoutPanel9;

        // NameBox (TextBox) so course name is editable
        private readonly List<(TextBox NameBox, NumericUpDown Credits, ComboBox Strength, Button Delete)> _courseRows = new();

        // Add Preset definition here (example Preset list)
        private static readonly List<(double MinGpa, string Letter, int Percent)> Preset = new()
        {
            (3.7, "A", 95),
            (3.0, "B", 85),
            (2.0, "C", 75),
            (1.0, "D", 65),
            (0.0, "F", 40)
        };

        private readonly DataStore _store = new();
        private UserData _userData = new();
        private Panel? _presetGradeScalePanel;
        private DataGridView? _presetGradeScaleView;

        public SemesterAnalysis()
        {
            InitializeComponent();
            _userData = _store.Load();

            // Initialize grade scale
            if (_userData.GradeScale == null)
            {
                _userData.GradeScale = GradeScale.GetPreset();
            }

            // Assign designer controls if they exist
            flowLayoutPanel6 = this.Controls.Find("flowLayoutPanel6", true).FirstOrDefault() as FlowLayoutPanel;
            flowLayoutPanel9 = this.Controls.Find("flowLayoutPanel9", true).FirstOrDefault() as FlowLayoutPanel;

            // wire up buttons
            button5.Click += AddCourseButton_Click;
            button2.Click += RunAnalysisButton_Click;
            button1.Click += Button1_CustomGradeScale_Click;
            
            // Wire up radio buttons
            radioButton1.CheckedChanged += RadioButton_CheckedChanged;
            radioButton2.CheckedChanged += RadioButton_CheckedChanged;
            
            // Initialize grade scale UI
            InitializeGradeScaleUI();

            // Initialize analysis options combo box
            if (this.Controls.Find("comboBox1", true).FirstOrDefault() is ComboBox analysisCombo)
            {
                analysisCombo.Items.AddRange(new object[] { "Equal Effort", "Credit Hour", "Difficulty-Based", "Combined Weight" });
                analysisCombo.SelectedIndex = 3; // Default to Combined Weight
            }

            // Initialize target GPA text box
            if (this.Controls.Find("textBox2", true).FirstOrDefault() is TextBox targetGpaBox)
            {
                targetGpaBox.Text = _userData.TargetGPA.ToString("F2");
            }

            // Load and initialize yearly credit hours, current GPA
            if (this.Controls.Find("numericUpDown1", true).FirstOrDefault() is NumericUpDown yearlyCredits)
            {
                yearlyCredits.Value = Math.Max(0, Math.Min(yearlyCredits.Maximum, _userData.TotalYearlyCreditHours));
            }
            if (this.Controls.Find("numericUpDown2", true).FirstOrDefault() is NumericUpDown pastCredits)
            {
                pastCredits.Value = Math.Max(0, Math.Min(pastCredits.Maximum, _userData.PastCompletedCreditHours));
            }
            if (this.Controls.Find("textBox1", true).FirstOrDefault() is TextBox currentGpaBox)
            {
                currentGpaBox.Text = _userData.CurrentGPA.ToString("F2");
            }

            // Load and initialize semester dates
            if (this.Controls.Find("dateTimePicker1", true).FirstOrDefault() is DateTimePicker startDatePicker)
            {
                startDatePicker.Value = _userData.SemesterStartDate < DateTime.Today ? DateTime.Today : _userData.SemesterStartDate;
            }
            if (this.Controls.Find("dateTimePicker2", true).FirstOrDefault() is DateTimePicker endDatePicker)
            {
                endDatePicker.Value = _userData.SemesterEndDate <= _userData.SemesterStartDate 
                    ? _userData.SemesterStartDate.AddMonths(4) 
                    : _userData.SemesterEndDate;
            }

            // Load existing courses
            var savedCourses = _userData.Courses ?? new List<CourseInfo>();
            if (savedCourses.Count > 0)
            {
                foreach (var course in savedCourses)
                {
                    // Add course row programmatically
                    AddCourseRow(course.Name, course.CreditHours, course.Strength, course.StartDate, course.EndDate);
                }
            }

            // runtime-safety: ensure flowLayoutPanel7 will scroll vertically and stack rows
            flowLayoutPanel7.AutoScroll = true;
            flowLayoutPanel7.WrapContents = false;
            flowLayoutPanel7.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel7.AutoSize = false;
            flowLayoutPanel7.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            // collect designer sample rows
            CollectDesignerRows();
            foreach (var r in _courseRows) EnsureStrengthItems(r.Strength);

            // keep dynamic rows sized when container resizes
            flowLayoutPanel7.SizeChanged += (s, e) => ResizeCourseRows();
        }

        private void InitializeGradeScaleUI()
        {
            // Set radio button states based on saved preference
            radioButton1.Checked = !_userData.UseCustomGradeScale;
            radioButton2.Checked = _userData.UseCustomGradeScale;
            
            // Create preset grade scale display panel
            _presetGradeScalePanel = new Panel
            {
                Location = new Point(radioButton1.Left, radioButton1.Bottom + 10),
                Size = new Size(groupBox1.Width - 20, 150),
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            _presetGradeScaleView = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                BackgroundColor = SystemColors.Control,
                RowHeadersVisible = false
            };

            _presetGradeScaleView.Columns.Add("Letter", "Letter");
            _presetGradeScaleView.Columns.Add("MinPercent", "Min %");
            _presetGradeScaleView.Columns.Add("MaxPercent", "Max %");
            _presetGradeScaleView.Columns.Add("GradePoints", "Grade Points");

            var presetScale = GradeScale.GetPreset();
            foreach (var item in presetScale.Items.OrderByDescending(i => i.GradePoints))
            {
                _presetGradeScaleView.Rows.Add(item.Letter, item.MinPercent, item.MaxPercent, item.GradePoints);
            }

            _presetGradeScalePanel.Controls.Add(_presetGradeScaleView);
            groupBox1.Controls.Add(_presetGradeScalePanel);

            UpdateGradeScaleDisplay();
        }

        private void UpdateGradeScaleDisplay()
        {
            if (_presetGradeScalePanel == null) return;

            _presetGradeScalePanel.Visible = radioButton1.Checked;
            button1.Enabled = radioButton2.Checked;
        }

        private void RadioButton_CheckedChanged(object? sender, EventArgs e)
        {
            UpdateGradeScaleDisplay();
            
            if (radioButton1.Checked)
            {
                _userData.UseCustomGradeScale = false;
                _userData.GradeScale = GradeScale.GetPreset();
                _store.Save(_userData);
            }
            else if (radioButton2.Checked)
            {
                _userData.UseCustomGradeScale = true;
                if (_userData.GradeScale == null)
                {
                    _userData.GradeScale = GradeScale.GetPreset();
                }
                _store.Save(_userData);
            }
        }

        private void Button1_CustomGradeScale_Click(object? sender, EventArgs e)
        {
            var currentScale = _userData.GradeScale ?? GradeScale.GetPreset();
            using var customForm = new CustomGradeScaleForm(currentScale);
            
            if (customForm.ShowDialog() == DialogResult.OK && customForm.GradeScale != null)
            {
                _userData.GradeScale = customForm.GradeScale;
                _userData.UseCustomGradeScale = true;
                radioButton2.Checked = true;
                _store.Save(_userData);
                MessageBox.Show("Custom grade scale saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void AddCourseRow(string name, int credits, string strength, DateTime? startDate = null, DateTime? endDate = null)
        {
            var rowPanel = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = false,
                WrapContents = false,
                Height = 36,
                Margin = new Padding(5),
                Padding = new Padding(6, 4, 6, 4),
                Width = flowLayoutPanel7.ClientSize.Width - 10
            };

            var nameBox = new TextBox
            {
                Text = name,
                Width = 200,
                Margin = new Padding(6, 6, 10, 6)
            };

            var creditsNumeric = new NumericUpDown
            {
                Minimum = 0,
                Maximum = 10,
                Value = credits,
                Width = 60,
                Margin = new Padding(6)
            };

            var strengthCombo = new ComboBox
            {
                Width = 100,
                Margin = new Padding(6),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            EnsureStrengthItems(strengthCombo);
            strengthCombo.SelectedItem = strength;

            var deleteBtn = new Button
            {
                Text = "Delete",
                AutoSize = true,
                Margin = new Padding(6),
                BackColor = Color.Red,
                ForeColor = Color.White
            };

            WireDeleteAction(deleteBtn, rowPanel);

            rowPanel.Controls.Add(nameBox);
            rowPanel.Controls.Add(creditsNumeric);
            rowPanel.Controls.Add(strengthCombo);
            rowPanel.Controls.Add(deleteBtn);

            // Store dates as Tag for later retrieval (courses use semester dates by default)
            rowPanel.Tag = new { StartDate = startDate, EndDate = endDate };

            flowLayoutPanel7.Controls.Add(rowPanel);
            _courseRows.Add((nameBox, creditsNumeric, strengthCombo, deleteBtn));
            ResizeCourseRows();
        }

        private void EnsureStrengthItems(ComboBox cb)
        {
            if (cb == null) return;
            if (cb.Items.Count == 0)
            {
                cb.Items.AddRange(new object[] { "Easy", "Medium", "Strong" });
                cb.SelectedIndex = 1;
            }
        }

        private void CollectDesignerRows()
        {
            TryAddExistingRow(flowLayoutPanel6);
            TryAddExistingRow(flowLayoutPanel9);
            // make sure designer rows match runtime sizing
            ResizeCourseRows();
        }

        public static (string Letter, int Percent) GetLetterAndPercent(double gpa)
        {
            gpa = Math.Clamp(gpa, 0.0, 4.0);
            foreach (var t in Preset)
            {
                if (gpa >= t.MinGpa)
                    return (t.Letter, t.Percent);
            }

            return ("F", 40);
        }

        private void AddCourseButton_Click(object sender, EventArgs e)
        {
            // Create a horizontal row panel to hold the course controls
            var rowPanel = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = false,                // fixed height, width will be set manually
                WrapContents = false,
                Height = 36,
                Margin = new Padding(5),
                Padding = new Padding(6, 4, 6, 4)
            };

            // IMPORTANT: Ensure row is wide enough so Delete button is visible
            rowPanel.Width = flowLayoutPanel7.ClientSize.Width - 10;

            // Create controls for the row
            var courseIndex = _courseRows.Count + 1;

            var nameBox = new TextBox
            {
                Text = $"Course {courseIndex}",
                Width = 200,
                Margin = new Padding(6, 6, 10, 6)
            };

            var credits = new NumericUpDown
            {
                Minimum = 0,
                Maximum = 10,
                Value = 3,
                Width = 60,
                Margin = new Padding(6)
            };

            var strength = new ComboBox
            {
                Width = 100,
                Margin = new Padding(6),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            EnsureStrengthItems(strength);

            // Make delete button clearly visible and accessible
            var deleteBtn = new Button
            {
                Text = "Delete",
                AutoSize = true,
                Margin = new Padding(6),
                BackColor = Color.Red,
                ForeColor = Color.White
            };

            // Wire delete action
            WireDeleteAction(deleteBtn, rowPanel);

            // Add controls to row
            rowPanel.Controls.Add(nameBox);
            rowPanel.Controls.Add(credits);
            rowPanel.Controls.Add(strength);
            rowPanel.Controls.Add(deleteBtn);

            // Add row to vertical container and track it
            flowLayoutPanel7.Controls.Add(rowPanel);
            _courseRows.Add((nameBox, credits, strength, deleteBtn));

            // ensure new row width matches container immediately
            ResizeCourseRows();
        }


        private void ResizeCourseRows()
        {
            if (flowLayoutPanel7 == null) return;

            // Calculate available width for each row
            int targetWidth = flowLayoutPanel7.ClientSize.Width
                              - SystemInformation.VerticalScrollBarWidth
                              - flowLayoutPanel7.Padding.Horizontal
                              - 10; // extra margin

            foreach (Control c in flowLayoutPanel7.Controls)
            {
                if (c is FlowLayoutPanel row)
                {
                    row.Width = targetWidth;

                    // Adjust inner controls proportionally if needed
                    int totalMargin = row.Padding.Horizontal;
                    int availableWidth = row.Width - totalMargin;

                    int deleteBtnWidth = 70; // fixed width for delete button
                    int creditsWidth = 60;   // width of numeric updown
                    int strengthWidth = 100; // width of combobox
                    int spacing = 6 * 4;     // approx spacing/margins between controls

                    int nameBoxWidth = availableWidth - (deleteBtnWidth + creditsWidth + strengthWidth + spacing);

                    // Make sure nameBoxWidth is at least 100
                    nameBoxWidth = Math.Max(nameBoxWidth, 100);

                    // Apply new width to nameBox (assume first control is nameBox)
                    if (row.Controls.Count >= 4 && row.Controls[0] is TextBox nameBox)
                    {
                        nameBox.Width = nameBoxWidth;
                    }
                }
            }
        }


        private void RenumberCourseNames()
        {
            for (int i = 0; i < _courseRows.Count; i++)
            {
                var (tb, _, _, _) = _courseRows[i];
                tb.Text = $"Course {i + 1}";
            }
        }

        private void RunAnalysisButton_Click(object sender, EventArgs e)
        {
            // Save user data from UI first
            if (!SaveUserDataFromUI())
                return;

            // Alternative Flow A1: No Data
            if (_courseRows.Count == 0)
            {
                MessageBox.Show(
                    "No semester data available. Please add courses before running analysis.\n\nWould you like to add a course now?",
                    "Analysis Unavailable",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information);
                return;
            }

            var courses = CollectCoursesFromUi();

            if (courses.Count == 0)
            {
                MessageBox.Show("Please enter at least one valid course name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Get analysis option
            AnalysisOption option = AnalysisOption.CombinedWeight;
            if (this.Controls.Find("comboBox1", true).FirstOrDefault() is ComboBox analysisCombo)
            {
                option = analysisCombo.SelectedIndex switch
                {
                    0 => AnalysisOption.EqualEffort,
                    1 => AnalysisOption.CreditHour,
                    2 => AnalysisOption.StrongWeak,
                    3 => AnalysisOption.CombinedWeight,
                    _ => AnalysisOption.CombinedWeight
                };
            }

            try
            {
                // Get grade scale
                var gradeScale = _userData.GradeScale ?? GradeScale.GetPreset();

                // Run analysis
                var engine = new SemesterAnalysisEngine();
                var analyzedCourses = engine.RunAnalysis(courses, _userData.TargetGPA, option, gradeScale);

                // Calculate GPA feasibility
                var (isFeasible, requiredGpa, feasibilityMessage) = SemesterAnalysisEngine.CalculateGpaFeasibility(
                    _userData.CurrentGPA,
                    _userData.TargetGPA,
                    _userData.PastCompletedCreditHours,
                    courses.Sum(c => c.CreditHours));

                if (!isFeasible)
                {
                    MessageBox.Show(feasibilityMessage, "GPA Feasibility Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Save courses
                _userData.Courses = analyzedCourses;
                _store.Save(_userData);

                // Display results
                var resultsForm = new AnalysisResults(analyzedCourses);
                resultsForm.ShowDialog();

                MessageBox.Show("Semester analysis completed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Alternative Flow A2: Calculation Error
                MessageBox.Show(
                    $"An error occurred during analysis calculation:\n\n{ex.Message}\n\nPlease check your input and try again.",
                    "Calculation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void TryAddExistingRow(FlowLayoutPanel panel)
        {
            if (panel == null) return;

            // Prefer an existing TextBox for the course name; if only a Label exists, replace it with TextBox
            TextBox nameBox = panel.Controls.OfType<TextBox>().FirstOrDefault();
            if (nameBox == null)
            {
                var nameLbl = panel.Controls.OfType<Label>().FirstOrDefault();
                if (nameLbl != null)
                {
                    // create TextBox to replace the label so name becomes editable
                    nameBox = new TextBox
                    {
                        Text = nameLbl.Text,
                        Width = Math.Max(150, nameLbl.PreferredSize.Width),
                        Margin = nameLbl.Margin
                    };
                    int idx = panel.Controls.GetChildIndex(nameLbl);
                    panel.Controls.Add(nameBox);
                    panel.Controls.SetChildIndex(nameBox, idx);
                    panel.Controls.Remove(nameLbl);
                }
            }

            var credits = panel.Controls.OfType<NumericUpDown>().FirstOrDefault();
            var strength = panel.Controls.OfType<ComboBox>().FirstOrDefault();
            var deleteBtn = panel.Controls.OfType<Button>().FirstOrDefault();

            if (deleteBtn == null)
            {
                // If the designer sample row has no delete button, create and append one
                deleteBtn = new Button
                {
                    Text = "Delete",
                    AutoSize = true,
                    Margin = new Padding(6),
                    FlatStyle = FlatStyle.System,
                    ForeColor = Color.Black,
                    TabStop = false
                };
                panel.Controls.Add(deleteBtn);
            }

            // Ensure delete button is wired and styled consistently
            if (deleteBtn != null)
            {
                WireDeleteAction(deleteBtn, panel);
            }

            if (nameBox != null && credits != null && strength != null && deleteBtn != null)
            {
                _courseRows.Add((nameBox, credits, strength, deleteBtn));
            }
        }

        // Helper to attach the same delete behavior to any row's delete button.
        // Removes the row from its parent container, removes tracked tuple, disposes row, renumbers and resizes.
        private void WireDeleteAction(Button deleteBtn, FlowLayoutPanel rowPanel)
        {
            // detach previous handlers to avoid duplicates
            deleteBtn.Click -= DeleteBtn_Click;
            deleteBtn.Click += DeleteBtn_Click;

            void DeleteBtn_Click(object? s, EventArgs ev)
            {
                try
                {
                    // remove tracked tuple(s) that reference this delete button
                    _courseRows.RemoveAll(t => t.Delete == deleteBtn);

                    // remove the UI row from its parent
                    if (rowPanel?.Parent is Control parent)
                    {
                        parent.Controls.Remove(rowPanel);
                    }
                    rowPanel?.Dispose();

                    RenumberCourseNames();
                    ResizeCourseRows();
                }
                finally
                {
                    // ensure local handler removed to prevent closure reference retention
                    deleteBtn.Click -= DeleteBtn_Click;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Proceed to Assignment Planner without losing current semester data.
        /// </summary>
        private void button4_Click(object sender, EventArgs e)
        {
            SaveSemesterData();
            using var assignmentForm = new AssignmentPlanner();
            assignmentForm.ShowDialog();
        }

        /// <summary>
        /// Semester-only planning: save data, ensure availability, then generate plan to calendar.
        /// </summary>
        private void button3_Click(object sender, EventArgs e)
        {
            if (!SaveSemesterData()) return;

            var dataRepository = new DataRepository();
            var availability = dataRepository.LoadAvailability();
            if (availability.TotalHoursPerWeek == 0)
            {
                using var availabilityForm = new AvailabilityManager();
                if (availabilityForm.ShowDialog() == DialogResult.OK)
                {
                    availability = availabilityForm.GetAvailability();
                    dataRepository.SaveAvailability(availability);
                }
                else
                {
                    MessageBox.Show(
                        "Please set your availability before generating a plan.",
                        "Availability Needed",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return;
                }
            }

            using var planner = new PlannerEngine();
            planner.GeneratePlan(PlanningWorkflow.SemesterOnly);
            planner.ShowDialog();
        }

        /// <summary>
        /// Persist semester courses from UI into storage. Returns false if validation fails.
        /// </summary>
        private bool SaveSemesterData()
        {
            if (_courseRows.Count == 0)
            {
                MessageBox.Show("Please add at least one course before proceeding.", "No Courses", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            var courses = CollectCoursesFromUi();
            if (courses.Count == 0)
            {
                MessageBox.Show("Please enter valid course names before proceeding.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Save user data including GPA and credit hours
            if (!SaveUserDataFromUI())
                return false;

            _userData.Courses = courses;
            _store.Save(_userData);
            return true;
        }

        private List<CourseInfo> CollectCoursesFromUi()
        {
            var courses = new List<CourseInfo>();
            
            // Get semester dates from UI or saved data
            DateTime semesterStart = _userData.SemesterStartDate;
            DateTime semesterEnd = _userData.SemesterEndDate;
            
            // Get from UI if available
            if (this.Controls.Find("dateTimePicker1", true).FirstOrDefault() is DateTimePicker startDatePicker)
            {
                semesterStart = startDatePicker.Value.Date;
            }
            if (this.Controls.Find("dateTimePicker2", true).FirstOrDefault() is DateTimePicker endDatePicker)
            {
                semesterEnd = endDatePicker.Value.Date;
            }

            // If dates are still default, use reasonable defaults
            if (semesterStart == default(DateTime) || semesterStart < DateTime.Today)
                semesterStart = DateTime.Today;
            if (semesterEnd == default(DateTime) || semesterEnd <= semesterStart)
                semesterEnd = semesterStart.AddMonths(4);

            foreach (var (nameBox, credits, strength, _) in _courseRows)
            {
                if (!string.IsNullOrWhiteSpace(nameBox.Text))
                {
                    // Try to get course-specific dates from existing course data
                    DateTime courseStart = semesterStart;
                    DateTime courseEnd = semesterEnd;
                    
                    var existingCourse = _userData.Courses?.FirstOrDefault(c => c.Name == nameBox.Text);
                    if (existingCourse != null && existingCourse.StartDate != default(DateTime))
                    {
                        courseStart = existingCourse.StartDate;
                    }
                    if (existingCourse != null && existingCourse.EndDate != default(DateTime))
                    {
                        courseEnd = existingCourse.EndDate;
                    }

                    courses.Add(new CourseInfo
                    {
                        Name = nameBox.Text,
                        CreditHours = (int)credits.Value,
                        Strength = strength.SelectedItem?.ToString() ?? "Medium",
                        StartDate = courseStart,
                        EndDate = courseEnd
                    });
                }
            }
            return courses;
        }

        private bool SaveUserDataFromUI()
        {
            // Save target GPA
            if (this.Controls.Find("textBox2", true).FirstOrDefault() is TextBox targetGpaBox)
            {
                if (!double.TryParse(targetGpaBox.Text, out double targetGpa) || targetGpa < 0 || targetGpa > 4.0)
                {
                    MessageBox.Show("Please enter a valid target GPA (0.0 - 4.0).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                _userData.TargetGPA = targetGpa;
            }

            // Save current GPA
            if (this.Controls.Find("textBox1", true).FirstOrDefault() is TextBox currentGpaBox)
            {
                if (!double.TryParse(currentGpaBox.Text, out double currentGpa) || currentGpa < 0 || currentGpa > 4.0)
                {
                    MessageBox.Show("Please enter a valid current GPA (0.0 - 4.0).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                _userData.CurrentGPA = currentGpa;
            }

            // Save yearly credit hours
            if (this.Controls.Find("numericUpDown1", true).FirstOrDefault() is NumericUpDown yearlyCredits)
            {
                _userData.TotalYearlyCreditHours = (int)yearlyCredits.Value;
            }

            // Save past completed credit hours
            if (this.Controls.Find("numericUpDown2", true).FirstOrDefault() is NumericUpDown pastCredits)
            {
                _userData.PastCompletedCreditHours = (int)pastCredits.Value;
            }

            // Save semester dates
            if (this.Controls.Find("dateTimePicker1", true).FirstOrDefault() is DateTimePicker startDatePicker)
            {
                _userData.SemesterStartDate = startDatePicker.Value.Date;
            }
            if (this.Controls.Find("dateTimePicker2", true).FirstOrDefault() is DateTimePicker endDatePicker)
            {
                _userData.SemesterEndDate = endDatePicker.Value.Date;
                
                // Validate end date is after start date
                if (_userData.SemesterEndDate <= _userData.SemesterStartDate)
                {
                    MessageBox.Show("Semester end date must be after start date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            _store.Save(_userData);
            return true;
        }
    }
}
