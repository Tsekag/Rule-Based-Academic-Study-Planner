﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using AcademicStudyPlanner.BusinessLogic;
using AcademicStudyPlanner.Models;
using AcademicStudyPlanner.Services;
using AcademicStudyPlanner.Views.plan;

namespace AcademicStudyPlanner.Views
{
    public partial class PlannerEngine : Form
    {
        private CalendarView? _calendarView;
        private readonly DataStore _store = new();
        private readonly WorkflowManager _workflowManager = new();
        private UserData _userData = new();

        public PlannerEngine()
        {
            InitializeComponent();
            _userData = _store.Load();
        }

        private void PlannerEngine_Load(object sender, EventArgs e)
        {
            if (_calendarView == null) InitializeCalendar();
        }

        private void InitializeCalendar()
        {
            _calendarView = new CalendarView { Dock = DockStyle.Fill };
            _calendarView.GeneratePlanClicked += CalendarView_GeneratePlanClicked;

            tableLayoutPanel1.Controls.Clear();
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(_calendarView, 0, 0);
        }

        public void GeneratePlan(PlanningWorkflow workflow)
        {
            if (_calendarView == null) InitializeCalendar();
            RunAndRenderPlan(workflow);
        }

        private void CalendarView_GeneratePlanClicked(object? sender, EventArgs e)
        {
            if (!EnsureAvailability()) return;
            using var workflowDialog = new WorkflowSelectionDialog();
            if (workflowDialog.ShowDialog() == DialogResult.OK)
                RunAndRenderPlan(workflowDialog.SelectedWorkflow);
        }

        private void RunAndRenderPlan(PlanningWorkflow workflow)
        {
            ReloadUserData();
            var sessions = _workflowManager.RunWorkflow(workflow, _userData).ToList();
            _store.Save(_userData);
            RenderSessions(sessions);

            if (sessions.Count > 0)
                MessageBox.Show($"Smart Plan Generated: {sessions.Count} sessions scheduled.", "Success");
        }

        private void RenderSessions(IEnumerable<StudySession> sessions)
        {
            if (_calendarView == null) return;
            _calendarView.ClearCalendar();

            foreach (var session in sessions)
            {
                int dayColumn = ((int)session.DayOfWeek + 6) % 7 + 1;
                int startRow = session.StartTime.Hour - 8;

                if (startRow < 0 || startRow >= 14) continue;

                int durationRows = (int)Math.Ceiling(session.Duration.TotalHours);
                if (durationRows < 1) durationRows = 1;
                if (startRow + durationRows > 14) durationRows = 14 - startRow;

                _calendarView.AddSession(
                    session.CourseName,
                    session.TaskTitle,
                    dayColumn,
                    startRow,
                    durationRows,
                    session.SessionColor);
            }
        }

        private void ReloadUserData() => _userData = _store.Load();

        private bool EnsureAvailability()
        {
            ReloadUserData();
            if (_userData.Availability != null && _userData.Availability.TotalHoursPerWeek > 0) return true;

            using var availabilityForm = new AvailabilityManager();
            if (availabilityForm.ShowDialog() == DialogResult.OK)
            {
                _userData.Availability = availabilityForm.GetAvailability();
                _store.Save(_userData);
                return true;
            }
            return false;
        }

        private void BtnProceedToAssignment_Click(object? sender, EventArgs e)
        {
            using var assignmentForm = new AssignmentPlanner();
            assignmentForm.ShowDialog();
            ReloadUserData();
        }

        private void BtnNext_Click(object? sender, EventArgs e) => CalendarView_GeneratePlanClicked(null, EventArgs.Empty);
        private void BtnGeneratePlanOnly_Click(object? sender, EventArgs e) => CalendarView_GeneratePlanClicked(null, EventArgs.Empty);
    }
}