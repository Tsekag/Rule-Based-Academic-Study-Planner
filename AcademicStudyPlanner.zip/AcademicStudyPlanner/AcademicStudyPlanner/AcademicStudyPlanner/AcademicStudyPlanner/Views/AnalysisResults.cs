using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using AcademicStudyPlanner.Models;

namespace AcademicStudyPlanner.Views
{
    public partial class AnalysisResults : Form
    {
        public AnalysisResults()
        {
            InitializeComponent();
            InitializeDataGridView();
        }

        public AnalysisResults(IEnumerable<CourseInfo> courses) : this()
        {
            Populate(courses);
        }

        private void InitializeDataGridView()
        {
            if (dgvResults != null)
            {
                dgvResults.Columns.Clear();
                dgvResults.Columns.Add("CourseName", "Course Name");
                dgvResults.Columns.Add("CreditHours", "Credits");
                dgvResults.Columns.Add("Strength", "Strength");
                dgvResults.Columns.Add("TargetGpa", "Target GPA");
                dgvResults.Columns.Add("Letter", "Letter Grade");
                dgvResults.Columns.Add("Score", "Target Score");
            }
        }

        // Populate table with computed analysis results
        public void Populate(IEnumerable<CourseInfo> courses)
        {
            if (dgvResults != null)
            {
                dgvResults.Rows.Clear();
                foreach (var c in courses)
                {
                    dgvResults.Rows.Add(
                        c.Name,
                        c.CreditHours,
                        c.Strength,
                        c.TargetGpa == 0 ? "" : c.TargetGpa.ToString("0.00"),
                        c.Letter,
                        c.Score == 0 ? "" : c.Score.ToString() + "%");
                }
            }
        }

        private void AnalysisResults_Load(object sender, EventArgs e)
        {

        }
    }
}