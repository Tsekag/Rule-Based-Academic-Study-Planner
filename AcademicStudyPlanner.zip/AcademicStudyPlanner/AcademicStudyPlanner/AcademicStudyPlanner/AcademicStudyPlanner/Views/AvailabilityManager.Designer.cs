namespace AcademicStudyPlanner.Views
{
    partial class AvailabilityManager
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            panelDays = new Panel();
            btnSave = new Button();
            labelTitle = new Label();
            SuspendLayout();
            // 
            // panelDays
            // 
            panelDays.AutoScroll = true;
            panelDays.Dock = DockStyle.Fill;
            panelDays.Location = new Point(0, 0);
            panelDays.Name = "panelDays";
            panelDays.Size = new Size(800, 500);
            panelDays.TabIndex = 0;
            // 
            // btnSave
            // 
            btnSave.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSave.Location = new Point(700, 460);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(100, 30);
            btnSave.TabIndex = 1;
            btnSave.Text = "Save Availability";
            btnSave.UseVisualStyleBackColor = true;
            // 
            // labelTitle
            // 
            labelTitle.AutoSize = true;
            labelTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            labelTitle.Location = new Point(10, 10);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(165, 21);
            labelTitle.TabIndex = 2;
            labelTitle.Text = "Set Your Availability";
            // 
            // AvailabilityManager
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 500);
            Controls.Add(labelTitle);
            Controls.Add(btnSave);
            Controls.Add(panelDays);
            Name = "AvailabilityManager";
            Text = "Availability Manager";
            Load += AvailabilityManager_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private Panel panelDays;
        private Button btnSave;
        private Label labelTitle;
    }
}



