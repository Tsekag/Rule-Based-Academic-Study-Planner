using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using AcademicStudyPlanner.Data;
using AcademicStudyPlanner.Models;

namespace AcademicStudyPlanner.Views
{
    public partial class AvailabilityManager : Form
    {
        private readonly DataRepository _dataRepository;
        private Availability _currentAvailability;
        private readonly Dictionary<DayOfWeek, CheckedListBox> _dayCheckBoxes = new();
        private readonly Dictionary<DayOfWeek, FlowLayoutPanel> _dayPanels = new();

        public AvailabilityManager()
        {
            InitializeComponent();
            _dataRepository = new DataRepository();
            _currentAvailability = _dataRepository.LoadAvailability();
            if (_currentAvailability.TotalHoursPerWeek == 0)
            {
                // Prefill a sensible default (8–22, Mon–Fri) so users are not blocked.
                var defaultAvailability = new Availability();
                for (int i = 1; i <= 5; i++)
                {
                    var day = (DayOfWeek)i;
                    defaultAvailability.AvailableSlots[day] = new List<(int, int)> { (8, 22) };
                }
                _currentAvailability = defaultAvailability;
            }
            InitializeDayControls();
            LoadAvailability();
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void InitializeDayControls()
        {
            // Create controls for each day of the week
            string[] dayNames = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
            DayOfWeek[] days = { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday, DayOfWeek.Sunday };

            for (int i = 0; i < days.Length; i++)
            {
                var day = days[i];
                var dayName = dayNames[i];

                // Create panel for the day
                var dayPanel = new Panel
                {
                    Dock = DockStyle.Top,
                    Height = 80,
                    BorderStyle = BorderStyle.FixedSingle,
                    Padding = new Padding(5)
                };

                // Day label
                var dayLabel = new Label
                {
                    Text = dayName,
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                    Location = new Point(5, 5)
                };
                dayPanel.Controls.Add(dayLabel);

                // Flow panel for time slots
                var slotsPanel = new FlowLayoutPanel
                {
                    Location = new Point(5, 25),
                    Size = new Size(dayPanel.Width - 10, 50),
                    Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                    AutoScroll = true
                };
                dayPanel.Controls.Add(slotsPanel);

                // Add/Remove buttons
                var addButton = new Button
                {
                    Text = "+",
                    Size = new Size(30, 25),
                    Location = new Point(dayPanel.Width - 80, 25),
                    Anchor = AnchorStyles.Top | AnchorStyles.Right
                };
                addButton.Click += (s, e) => AddTimeSlot(day, slotsPanel);
                dayPanel.Controls.Add(addButton);

                _dayPanels[day] = slotsPanel;
                panelDays.Controls.Add(dayPanel);
            }

            // Set up save button
            btnSave.Click += BtnSave_Click;
        }

        private void AddTimeSlot(DayOfWeek day, FlowLayoutPanel panel)
        {
            var slotPanel = new Panel
            {
                Size = new Size(200, 40),
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(3)
            };

            var startLabel = new Label
            {
                Text = "From:",
                Location = new Point(5, 10),
                AutoSize = true
            };
            slotPanel.Controls.Add(startLabel);

            var startNumeric = new NumericUpDown
            {
                Minimum = 0,
                Maximum = 23,
                Value = 8,
                Location = new Point(50, 8),
                Width = 50,
                Tag = "start"
            };
            slotPanel.Controls.Add(startNumeric);

            var endLabel = new Label
            {
                Text = "To:",
                Location = new Point(110, 10),
                AutoSize = true
            };
            slotPanel.Controls.Add(endLabel);

            var endNumeric = new NumericUpDown
            {
                Minimum = 0,
                Maximum = 23,
                Value = 22,
                Location = new Point(135, 8),
                Width = 50,
                Tag = "end"
            };
            slotPanel.Controls.Add(endNumeric);

            var removeButton = new Button
            {
                Text = "×",
                Size = new Size(25, 25),
                Location = new Point(170, 7),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            removeButton.Click += (s, e) =>
            {
                panel.Controls.Remove(slotPanel);
                slotPanel.Dispose();
            };
            slotPanel.Controls.Add(removeButton);

            panel.Controls.Add(slotPanel);
        }

        private void LoadAvailability()
        {
            foreach (var kvp in _dayPanels)
            {
                var day = kvp.Key;
                var panel = kvp.Value;

                panel.Controls.Clear();

                if (_currentAvailability.AvailableSlots.ContainsKey(day))
                {
                    foreach (var (start, end) in _currentAvailability.AvailableSlots[day])
                    {
                        AddTimeSlotWithValues(day, panel, start, end);
                    }
                }
            }
        }

        private void AddTimeSlotWithValues(DayOfWeek day, FlowLayoutPanel panel, int startHour, int endHour)
        {
            var slotPanel = new Panel
            {
                Size = new Size(200, 40),
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(3)
            };

            var startLabel = new Label
            {
                Text = "From:",
                Location = new Point(5, 10),
                AutoSize = true
            };
            slotPanel.Controls.Add(startLabel);

            var startNumeric = new NumericUpDown
            {
                Minimum = 0,
                Maximum = 23,
                Value = startHour,
                Location = new Point(50, 8),
                Width = 50,
                Tag = "start"
            };
            slotPanel.Controls.Add(startNumeric);

            var endLabel = new Label
            {
                Text = "To:",
                Location = new Point(110, 10),
                AutoSize = true
            };
            slotPanel.Controls.Add(endLabel);

            var endNumeric = new NumericUpDown
            {
                Minimum = 0,
                Maximum = 23,
                Value = endHour,
                Location = new Point(135, 8),
                Width = 50,
                Tag = "end"
            };
            slotPanel.Controls.Add(endNumeric);

            var removeButton = new Button
            {
                Text = "×",
                Size = new Size(25, 25),
                Location = new Point(170, 7),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            removeButton.Click += (s, e) =>
            {
                panel.Controls.Remove(slotPanel);
                slotPanel.Dispose();
            };
            slotPanel.Controls.Add(removeButton);

            panel.Controls.Add(slotPanel);
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            var availability = new Availability();

            foreach (var kvp in _dayPanels)
            {
                var day = kvp.Key;
                var panel = kvp.Value;
                var slots = new List<(int, int)>();

                foreach (Control control in panel.Controls)
                {
                    if (control is Panel slotPanel)
                    {
                        var startNumeric = slotPanel.Controls.OfType<NumericUpDown>().FirstOrDefault(n => (n.Tag as string) == "start");
                        var endNumeric = slotPanel.Controls.OfType<NumericUpDown>().FirstOrDefault(n => (n.Tag as string) == "end");

                        if (startNumeric != null && endNumeric != null)
                        {
                            int start = (int)startNumeric.Value;
                            int end = (int)endNumeric.Value;

                            if (start < end)
                            {
                                slots.Add((start, end));
                            }
                        }
                    }
                }

                if (slots.Count > 0)
                {
                    availability.AvailableSlots[day] = slots;
                }
            }

            _currentAvailability = availability;
            _dataRepository.SaveAvailability(availability);

            MessageBox.Show("Availability saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.DialogResult = DialogResult.OK;
        }

        public Availability GetAvailability()
        {
            return _currentAvailability;
        }

        private void AvailabilityManager_Load(object sender, EventArgs e)
        {

        }
    }
}

