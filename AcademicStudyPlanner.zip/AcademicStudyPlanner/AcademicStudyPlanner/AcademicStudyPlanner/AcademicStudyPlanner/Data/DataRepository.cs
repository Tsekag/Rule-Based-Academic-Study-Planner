using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using AcademicStudyPlanner.Models;
using AcademicStudyPlanner.BusinessLogic;

namespace AcademicStudyPlanner.Data
{
    /// <summary>
    /// Data layer for storing and retrieving application data.
    /// </summary>
    public class DataRepository
    {
        private readonly string _dataDirectory;
        private const string CoursesFile = "courses.json";
        private const string AssignmentsFile = "assignments.json";
        private const string AvailabilityFile = "availability.json";
        private const string PreferencesFile = "preferences.json";
        private const string GradeScaleFile = "gradescale.json";

        public DataRepository(string? dataDirectory = null)
        {
            _dataDirectory = dataDirectory ?? Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "AcademicStudyPlanner");

            if (!Directory.Exists(_dataDirectory))
            {
                Directory.CreateDirectory(_dataDirectory);
            }
        }

        #region Courses

        public void SaveCourses(List<CourseInfo> courses)
        {
            var filePath = Path.Combine(_dataDirectory, CoursesFile);
            var json = JsonSerializer.Serialize(courses, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        public List<CourseInfo> LoadCourses()
        {
            var filePath = Path.Combine(_dataDirectory, CoursesFile);
            if (!File.Exists(filePath))
                return new List<CourseInfo>();

            try
            {
                var json = File.ReadAllText(filePath);
                return JsonSerializer.Deserialize<List<CourseInfo>>(json) ?? new List<CourseInfo>();
            }
            catch
            {
                return new List<CourseInfo>();
            }
        }

        #endregion

        #region Assignments

        public void SaveAssignments(List<Assignment> assignments)
        {
            var filePath = Path.Combine(_dataDirectory, AssignmentsFile);
            var json = JsonSerializer.Serialize(assignments, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        public List<Assignment> LoadAssignments()
        {
            var filePath = Path.Combine(_dataDirectory, AssignmentsFile);
            if (!File.Exists(filePath))
                return new List<Assignment>();

            try
            {
                var json = File.ReadAllText(filePath);
                return JsonSerializer.Deserialize<List<Assignment>>(json) ?? new List<Assignment>();
            }
            catch
            {
                return new List<Assignment>();
            }
        }

        #endregion

        #region Availability

        public void SaveAvailability(Availability availability)
        {
            var filePath = Path.Combine(_dataDirectory, AvailabilityFile);

            // Create a simple serializable version (using a helper class instead of Tuple)
            var serializableData = availability.AvailableSlots.ToDictionary(
                k => k.Key.ToString(),
                v => v.Value.Select(slot => new { Start = slot.Item1, End = slot.Item2 }).ToList()
            );

            var json = JsonSerializer.Serialize(serializableData, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        public Availability LoadAvailability()
        {
            var filePath = Path.Combine(_dataDirectory, AvailabilityFile);
            if (!File.Exists(filePath)) return GetDefaultAvailability();

            try
            {
                var json = File.ReadAllText(filePath);
                // Using dynamic or a dictionary of objects to bypass the Tuple deserialization issue
                var rawData = JsonSerializer.Deserialize<Dictionary<string, List<JsonElement>>>(json);
                var availability = new Availability();

                foreach (var kvp in rawData ?? new())
                {
                    if (Enum.TryParse<DayOfWeek>(kvp.Key, out var day))
                    {
                        var slots = new List<(int, int)>();
                        foreach (var element in kvp.Value)
                        {
                            int s = element.GetProperty("Start").GetInt32();
                            int e = element.GetProperty("End").GetInt32();
                            slots.Add((s, e));
                        }
                        availability.AvailableSlots[day] = slots;
                    }
                }
                return availability.AvailableSlots.Count > 0 ? availability : GetDefaultAvailability();
            }
            catch
            {
                return GetDefaultAvailability();
            }
        }
        private Availability GetDefaultAvailability()
        {
            var availability = new Availability();
            for (int i = 1; i <= 5; i++) // Monday to Friday
            {
                var day = (DayOfWeek)i;
                availability.AvailableSlots[day] = new List<(int, int)> { (8, 22) };
            }
            return availability;
        }

        #endregion

        #region Preferences

        public void SavePreferences(UserPreferences preferences)
        {
            var filePath = Path.Combine(_dataDirectory, PreferencesFile);
            var json = JsonSerializer.Serialize(preferences, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        public UserPreferences LoadPreferences()
        {
            var filePath = Path.Combine(_dataDirectory, PreferencesFile);
            if (!File.Exists(filePath))
                return new UserPreferences();

            try
            {
                var json = File.ReadAllText(filePath);
                return JsonSerializer.Deserialize<UserPreferences>(json) ?? new UserPreferences();
            }
            catch
            {
                return new UserPreferences();
            }
        }

        #endregion

        #region GradeScale

        public void SaveGradeScale(GradeScale gradeScale)
        {
            var filePath = Path.Combine(_dataDirectory, GradeScaleFile);
            var json = JsonSerializer.Serialize(gradeScale, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        public GradeScale LoadGradeScale()
        {
            var filePath = Path.Combine(_dataDirectory, GradeScaleFile);
            if (!File.Exists(filePath))
                return GradeScale.GetPreset();

            try
            {
                var json = File.ReadAllText(filePath);
                var scale = JsonSerializer.Deserialize<GradeScale>(json);
                if (scale != null && scale.Items != null && scale.Items.Count > 0)
                {
                    if (scale.Validate(out _))
                        return scale;
                }
            }
            catch
            {
                // Return preset on error
            }

            return GradeScale.GetPreset();
        }

        #endregion
    }

    /// <summary>
    /// User preferences for the application.
    /// </summary>
    public class UserPreferences
    {
        public double DefaultTargetGpa { get; set; } = 3.5;
        public string DefaultAnalysisOption { get; set; } = "CombinedWeight";
        public PlanningWorkflow DefaultWorkflow { get; set; } = PlanningWorkflow.Combined;
        public bool UseCustomGradeScale { get; set; } = false;
    }
}

