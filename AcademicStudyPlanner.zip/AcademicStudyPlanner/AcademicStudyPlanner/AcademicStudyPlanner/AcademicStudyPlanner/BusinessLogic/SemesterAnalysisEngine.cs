using System;
using System.Collections.Generic;
using System.Linq;
using AcademicStudyPlanner.Models;

namespace AcademicStudyPlanner.BusinessLogic
{
    /// <summary>
    /// Business logic for semester analysis using rule-based algorithms.
    /// </summary>
    public class SemesterAnalysisEngine
    {
        /// <summary>
        /// Runs semester analysis based on the selected analysis option.
        /// </summary>
        public List<CourseInfo> RunAnalysis(
            List<CourseInfo> courses,
            double targetGpa,
            AnalysisOption option,
            GradeScale? gradeScale = null)
        {
            if (courses == null || courses.Count == 0)
                return new List<CourseInfo>();

            gradeScale ??= GradeScale.GetPreset();

            var analyzedCourses = courses.Select(c => new CourseInfo
            {
                Name = c.Name,
                CreditHours = c.CreditHours,
                Strength = c.Strength,
                TargetGpa = targetGpa
            }).ToList();

            switch (option)
            {
                case AnalysisOption.EqualEffort:
                    return ApplyEqualEffortAnalysis(analyzedCourses, targetGpa, gradeScale);
                case AnalysisOption.CreditHour:
                    return ApplyCreditHourAnalysis(analyzedCourses, targetGpa, gradeScale);
                case AnalysisOption.StrongWeak:
                    return ApplyStrongWeakAnalysis(analyzedCourses, targetGpa, gradeScale);
                case AnalysisOption.CombinedWeight:
                    return ApplyCombinedWeightAnalysis(analyzedCourses, targetGpa, gradeScale);
                default:
                    return analyzedCourses;
            }
        }

        /// <summary>
        /// Calculates GPA feasibility based on current GPA, target GPA, and credit hours.
        /// </summary>
        public static (bool IsFeasible, double RequiredGpa, string Message) CalculateGpaFeasibility(
            double currentGpa,
            double targetGpa,
            int pastCompletedCredits,
            int currentSemesterCredits)
        {
            if (currentSemesterCredits == 0)
                return (false, 0, "No courses in current semester.");

            // Calculate required GPA for current semester to achieve target
            // Formula: (currentGPA * pastCredits + requiredGPA * currentCredits) / (pastCredits + currentCredits) = targetGPA
            // Solving for requiredGPA:
            double totalCredits = pastCompletedCredits + currentSemesterCredits;
            if (totalCredits == 0)
                return (false, 0, "Invalid credit hours.");

            double requiredGpa = ((targetGpa * totalCredits) - (currentGpa * pastCompletedCredits)) / currentSemesterCredits;
            
            bool isFeasible = requiredGpa >= 0 && requiredGpa <= 4.0;
            string message = isFeasible
                ? $"To achieve a target GPA of {targetGpa:F2}, you need a GPA of {requiredGpa:F2} this semester."
                : $"Target GPA of {targetGpa:F2} is not achievable. Required GPA ({requiredGpa:F2}) is out of range.";

            return (isFeasible, requiredGpa, message);
        }

        /// <summary>
        /// Equal Effort: Distributes study time equally across all courses.
        /// </summary>
        private List<CourseInfo> ApplyEqualEffortAnalysis(List<CourseInfo> courses, double targetGpa, GradeScale gradeScale)
        {
            var (letter, percent) = GetLetterAndPercent(targetGpa, gradeScale);
            foreach (var course in courses)
            {
                course.Letter = letter;
                course.Score = percent;
            }
            return courses;
        }

        /// <summary>
        /// Credit Hour: Allocates study time proportionally based on credit hours.
        /// </summary>
        private List<CourseInfo> ApplyCreditHourAnalysis(List<CourseInfo> courses, double targetGpa, GradeScale gradeScale)
        {
            int totalCredits = courses.Sum(c => c.CreditHours);
            if (totalCredits == 0) return courses;

            var (letter, basePercent) = GetLetterAndPercent(targetGpa, gradeScale);

            foreach (var course in courses)
            {
                // Higher credit hours get slightly higher target scores
                double creditWeight = (double)course.CreditHours / totalCredits;
                int adjustedPercent = basePercent + (int)(creditWeight * 5); // Up to 5% bonus
                course.Letter = letter;
                course.Score = Math.Min(100, adjustedPercent);
            }
            return courses;
        }

        /// <summary>
        /// Strong/Weak: Adjusts targets based on course difficulty (Easy courses get lower targets, Strong/Hard get higher).
        /// </summary>
        private List<CourseInfo> ApplyStrongWeakAnalysis(List<CourseInfo> courses, double targetGpa, GradeScale gradeScale)
        {
            var (letter, basePercent) = GetLetterAndPercent(targetGpa, gradeScale);

            foreach (var course in courses)
            {
                int adjustment = course.Strength switch
                {
                    "Easy" => -5,       // Easy courses: slightly lower target
                    "Strong" => +10,    // Strong/Difficult courses: higher target to compensate
                    _ => 0              // Medium: no adjustment
                };

                course.Letter = letter;
                course.Score = Math.Clamp(basePercent + adjustment, 0, 100);
            }
            return courses;
        }

        /// <summary>
        /// Combined Weight: Combines credit hours and difficulty for optimal allocation.
        /// </summary>
        private List<CourseInfo> ApplyCombinedWeightAnalysis(List<CourseInfo> courses, double targetGpa, GradeScale gradeScale)
        {
            int totalCredits = courses.Sum(c => c.CreditHours);
            if (totalCredits == 0) return courses;

            var (letter, basePercent) = GetLetterAndPercent(targetGpa, gradeScale);

            foreach (var course in courses)
            {
                // Credit hour weight (0.0 to 1.0)
                double creditWeight = totalCredits > 0 ? (double)course.CreditHours / totalCredits : 0.0;

                // Difficulty weight
                int difficultyAdjustment = course.Strength switch
                {
                    "Easy" => -8,
                    "Strong" => +12,    // Strong = difficult course
                    _ => 0              // Medium
                };

                // Combined calculation
                int creditAdjustment = (int)(creditWeight * 8); // Up to 8% from credits
                int finalScore = basePercent + creditAdjustment + difficultyAdjustment;

                course.Letter = letter;
                course.Score = Math.Clamp(finalScore, 0, 100);
            }
            return courses;
        }

        /// <summary>
        /// Gets letter grade and percentage based on GPA using the provided grade scale.
        /// </summary>
        public static (string Letter, int Percent) GetLetterAndPercent(double gpa, GradeScale? gradeScale = null)
        {
            gradeScale ??= GradeScale.GetPreset();
            return gradeScale.GetLetterAndPercent(gpa);
        }
    }
}



