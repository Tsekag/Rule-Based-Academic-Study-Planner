namespace AcademicStudyPlanner.BusinessLogic
{
    /// <summary>
    /// Enumeration of available semester analysis options.
    /// </summary>
    public enum AnalysisOption
    {
        EqualEffort,
        CreditHour,
        StrongWeak,
        CombinedWeight
    }
}



