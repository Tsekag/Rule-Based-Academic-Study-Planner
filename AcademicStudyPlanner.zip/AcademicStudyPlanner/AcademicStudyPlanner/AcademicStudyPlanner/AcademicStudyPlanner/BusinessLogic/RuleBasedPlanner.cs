using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using AcademicStudyPlanner.Models;

namespace AcademicStudyPlanner.BusinessLogic
{
    public class RuleBasedPlanner
    {
        private const double MinSessionHours = 1.0;
        private const double MaxSessionHours = 3.0;

        private class DemandItem
        {
            public FocusType FocusType { get; set; }
            public string ReferenceId { get; set; } = string.Empty;
            public string DisplayTitle { get; set; } = string.Empty;
            public string CourseName { get; set; } = string.Empty;
            public double HoursRemaining { get; set; }
            public double PriorityScore { get; set; }
            public DateTime EarliestStart { get; set; } // Will not schedule before this
            public DateTime LatestEnd { get; set; }     // Will not schedule after this (Deadline)
        }

        private class TimeSlot
        {
            public DateTime Start { get; set; }
            public DateTime End { get; set; }
            public bool IsFree { get; set; } = true;
        }

        public List<StudySession> GeneratePlan(
            PlanningWorkflow workflow,
            List<CourseInfo>? courses = null,
            List<Assignment>? assignments = null,
            Availability? availability = null,
            double currentGpa = 2.0,
            double targetGpa = 3.5,
            DateTime? semesterStart = null,
            DateTime? semesterEnd = null)
        {
            if (availability == null || availability.AvailableSlots == null || availability.AvailableSlots.Count == 0)
                availability = GetDefaultAvailability();

            courses ??= new List<CourseInfo>();
            assignments ??= new List<Assignment>();

            // Use provided semester dates or default to current date range
            DateTime planStart = semesterStart ?? DateTime.Today;
            DateTime planEnd = semesterEnd ?? DateTime.Today.AddMonths(4);

            // 1. Calculate Smart Intensity Factor (The GPA Gap)
            // If the student has a low GPA but a high target, increase study volume by up to 50%
            double gpaGap = Math.Max(0, targetGpa - currentGpa);
            double smartIntensityMultiplier = 1.0 + (gpaGap * 0.3);

            // 2. Build demand based on workflow
            var demand = workflow switch
            {
                PlanningWorkflow.AssignmentOnly => BuildAssignmentOnlyDemand(assignments),
                PlanningWorkflow.SemesterOnly => BuildSemesterOnlyDemand(courses, smartIntensityMultiplier, planStart, planEnd),
                PlanningWorkflow.Combined => BuildCombinedDemand(courses, assignments, smartIntensityMultiplier, planStart, planEnd),
                _ => new List<DemandItem>()
            };

            if (demand.Count == 0) return new List<StudySession>();

            // 3. Generate Free Time Slots (respecting availability and semester dates)
            var slots = BuildTimeSlots(availability, planStart, planEnd);

            // 4. Smart Allocation (Constraint-Based)
            var sessions = AllocateDemandToSlots(demand, slots);

            return sessions.OrderBy(s => s.StartTime).ToList();
        }

        private List<DemandItem> BuildSemesterOnlyDemand(List<CourseInfo> courses, double intensity, DateTime semesterStart, DateTime semesterEnd)
        {
            var demand = new List<DemandItem>();
            foreach (var c in courses)
            {
                // Use course-specific dates if available, otherwise use semester dates
                DateTime courseStart = c.StartDate != default(DateTime) ? c.StartDate : semesterStart;
                DateTime courseEnd = c.EndDate != default(DateTime) ? c.EndDate : semesterEnd;

                // Calculate weeks in course duration
                double weeks = Math.Max(1, (courseEnd - courseStart).TotalDays / 7.0);

                // SMART LOGIC: Increase hours for "Strong" (difficult) courses and high Credit Hours
                double baseHours = 3.0; // Base hours per week
                double strengthMultiplier = c.Strength == "Strong" ? 1.8 : (c.Strength == "Easy" ? 0.6 : 1.0);
                double creditMultiplier = 1.0 + (c.CreditHours * 0.1);

                double calculatedWeeklyHours = baseHours * strengthMultiplier * creditMultiplier * intensity;
                double totalHours = calculatedWeeklyHours * weeks;

                demand.Add(new DemandItem
                {
                    FocusType = FocusType.GeneralReview,
                    CourseName = c.Name,
                    DisplayTitle = $"Review: {c.Name}",
                    HoursRemaining = totalHours,
                    PriorityScore = calculatedWeeklyHours * 10,
                    EarliestStart = courseStart.Date,
                    LatestEnd = courseEnd.Date
                });
            }
            return demand;
        }

        private List<DemandItem> BuildAssignmentOnlyDemand(List<Assignment> assignments)
        {
            var demand = new List<DemandItem>();
            var now = DateTime.Today;

            foreach (var a in assignments.Where(a => !a.IsCompleted))
            {
                double hours = Math.Max(1.0, a.EstimatedDuration.TotalHours);
                int daysUntilDue = Math.Max(0, (a.DueDate.Date - now).Days);

                // URGENCY LOGIC: Deadlines closer than 3 days get massive priority boost
                double urgency = (100.0 / (daysUntilDue + 1)) + (hours * 2);

                demand.Add(new DemandItem
                {
                    FocusType = FocusType.SpecificTask,
                    ReferenceId = a.Id,
                    CourseName = a.CourseName,
                    DisplayTitle = a.Title,
                    HoursRemaining = hours,
                    PriorityScore = urgency,
                    EarliestStart = a.StartDate.Date, // CONSTRAINT: Cannot start before this
                    LatestEnd = a.DueDate.Date       // CONSTRAINT: Must end by this
                });
            }
            return demand;
        }

        private List<DemandItem> BuildCombinedDemand(List<CourseInfo> courses, List<Assignment> assignments, double intensity, DateTime semesterStart, DateTime semesterEnd)
        {
            var demand = BuildSemesterOnlyDemand(courses, intensity, semesterStart, semesterEnd);
            var assignmentDemand = BuildAssignmentOnlyDemand(assignments);

            // Ensure Assignments always take precedence over general review
            foreach (var d in assignmentDemand) d.PriorityScore += 500;

            demand.AddRange(assignmentDemand);
            return demand;
        }

        private List<TimeSlot> BuildTimeSlots(Availability availability, DateTime semesterStart, DateTime semesterEnd)
        {
            var slots = new List<TimeSlot>();
            DateTime start = semesterStart.Date;
            DateTime end = semesterEnd.Date;
            
            for (var day = start; day <= end; day = day.AddDays(1))
            {
                if (availability.AvailableSlots.TryGetValue(day.DayOfWeek, out var ranges))
                {
                    foreach (var (startH, endH) in ranges)
                    {
                        if (endH > startH)
                        {
                            DateTime slotStart = day.AddHours(startH);
                            DateTime slotEnd = day.AddHours(endH);
                            
                            // Ensure slot doesn't extend beyond semester end
                            if (slotStart <= end)
                            {
                                if (slotEnd > end)
                                    slotEnd = end.AddDays(1).Date; // End of semester day
                                
                                slots.Add(new TimeSlot { Start = slotStart, End = slotEnd });
                            }
                        }
                    }
                }
            }
            return slots.OrderBy(s => s.Start).ToList();
        }

        private List<StudySession> AllocateDemandToSlots(List<DemandItem> demand, List<TimeSlot> slots)
        {
            var sessions = new List<StudySession>();

            // Sort by priority (Urgent assignments first)
            foreach (var d in demand.OrderByDescending(x => x.PriorityScore))
            {
                foreach (var slot in slots.Where(s => s.IsFree).ToList())
                {
                    if (d.HoursRemaining <= 0) break;

                    // SMART CONSTRAINT CHECK:
                    // 1. Is the current slot AFTER the assignment's/course's StartDate?
                    // 2. Is the current slot BEFORE the assignment's/course's EndDate?
                    // 3. Ensure session end time doesn't exceed the latest end date
                    if (slot.Start < d.EarliestStart || slot.Start.Date > d.LatestEnd.Date)
                        continue;
                    
                    // Additional check: ensure the session doesn't extend beyond the latest end date
                    DateTime proposedEnd = slot.Start.AddHours(Math.Min(d.HoursRemaining, Math.Min((slot.End - slot.Start).TotalHours, MaxSessionHours)));
                    if (proposedEnd.Date > d.LatestEnd.Date)
                        continue;

                    double slotHours = (slot.End - slot.Start).TotalHours;
                    if (slotHours < 0.5) continue;

                    double allocHours = Math.Min(d.HoursRemaining, Math.Min(slotHours, MaxSessionHours));
                    DateTime sessionEnd = slot.Start.AddHours(allocHours);

                    // Create the session with FULL DATA for the UI
                    sessions.Add(new StudySession
                    {
                        CourseName = d.CourseName,
                        TaskTitle = d.DisplayTitle,
                        StartTime = slot.Start,
                        EndTime = sessionEnd,
                        SessionColor = GetSmartColor(d),
                        Priority = (int)d.PriorityScore
                    });

                    d.HoursRemaining -= allocHours;

                    // Update slot availability
                    if ((slot.End - sessionEnd).TotalHours < 0.5) slot.IsFree = false;
                    else slot.Start = sessionEnd;
                }
            }
            return sessions;
        }

        private Color GetSmartColor(DemandItem item)
        {
            // Generate a unique, consistent color based on the Course Name
            int hash = item.CourseName.GetHashCode();

            // Create a color using the hash bits (keeping it in a readable "pastel" range)
            int r = Math.Abs((hash & 0xFF0000) >> 16) % 100 + 120;
            int g = Math.Abs((hash & 0x00FF00) >> 8) % 100 + 120;
            int b = Math.Abs(hash & 0x0000FF) % 100 + 120;

            // Assignment specific color logic (red for very urgent)
            if (item.FocusType == FocusType.SpecificTask)
            {
                int daysLeft = (item.LatestEnd.Date - DateTime.Today).Days;
                if (daysLeft < 3) return Color.FromArgb(230, 80, 80); // Red
            }

            return Color.FromArgb(r, g, b);
        }

        private Availability GetDefaultAvailability()
        {
            var availability = new Availability();
            for (int i = 1; i <= 7; i++) // Default Mon-Sun 8am-10pm
                availability.AvailableSlots[(DayOfWeek)(i % 7)] = new List<(int, int)> { (8, 22) };
            return availability;
        }
    }

    public enum FocusType { GeneralReview, SpecificTask }
    public enum PlanningWorkflow { Combined, SemesterOnly, AssignmentOnly }
}