using AcademicStudyPlanner.Data;
using AcademicStudyPlanner.Models;

namespace AcademicStudyPlanner.Services
{
    /// <summary>
    /// Thin wrapper that persists UserData via the existing DataRepository.
    /// Keeps all forms in sync without adding extra dependencies.
    /// </summary>
    public class DataStore
    {
        private readonly DataRepository _repository = new();

        public UserData Load()
        {
            return new UserData
            {
                Courses = _repository.LoadCourses(),
                Assignments = _repository.LoadAssignments(),
                Availability = _repository.LoadAvailability(),
                GradeScale = _repository.LoadGradeScale(),
                UseCustomGradeScale = _repository.LoadPreferences().UseCustomGradeScale
            };
        }

        public void Save(UserData data)
        {
            _repository.SaveCourses(data.Courses);
            _repository.SaveAssignments(data.Assignments);
            _repository.SaveAvailability(data.Availability);
            
            if (data.GradeScale != null)
            {
                _repository.SaveGradeScale(data.GradeScale);
            }

            var prefs = _repository.LoadPreferences();
            prefs.UseCustomGradeScale = data.UseCustomGradeScale;
            _repository.SavePreferences(prefs);
        }
    }
}

