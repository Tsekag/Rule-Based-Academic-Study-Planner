using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AcademicStudyPlanner.Models;

namespace AcademicStudyPlanner.Services
{
    /// <summary>
    /// Service for managing local reminders for task deadlines.
    /// </summary>
    public class ReminderService : IDisposable
    {
        private readonly string _remindersFile;
        private System.Threading.Timer? _checkTimer;
        private bool _disposed = false;
        private readonly List<Reminder> _reminders = new();

        public ReminderService()
        {
            var dataDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "AcademicStudyPlanner");
            Directory.CreateDirectory(dataDirectory);
            _remindersFile = Path.Combine(dataDirectory, "reminders.json");
            LoadReminders();
            StartReminderCheck();
        }

        /// <summary>
        /// Registers a reminder for an assignment deadline.
        /// </summary>
        public void RegisterReminder(Assignment assignment, int minutesBeforeDeadline = 60)
        {
            if (assignment.IsCompleted)
                return;

            var reminderTime = assignment.DueDate.AddMinutes(-minutesBeforeDeadline);
            
            // Don't create reminders for past dates
            if (reminderTime < DateTime.Now)
                return;

            // Remove existing reminder for this assignment
            _reminders.RemoveAll(r => r.AssignmentId == assignment.Id);

            var reminder = new Reminder
            {
                AssignmentId = assignment.Id,
                AssignmentTitle = assignment.Title,
                CourseName = assignment.CourseName,
                DueDate = assignment.DueDate,
                ReminderTime = reminderTime,
                IsShown = false
            };

            _reminders.Add(reminder);
            SaveReminders();
        }

        /// <summary>
        /// Removes reminders for a specific assignment.
        /// </summary>
        public void RemoveReminder(string assignmentId)
        {
            _reminders.RemoveAll(r => r.AssignmentId == assignmentId);
            SaveReminders();
        }

        /// <summary>
        /// Updates reminders for all assignments in the list.
        /// </summary>
        public void UpdateReminders(List<Assignment> assignments)
        {
            // Remove reminders for assignments that no longer exist or are completed
            var existingIds = assignments.Where(a => !a.IsCompleted).Select(a => a.Id).ToHashSet();
            _reminders.RemoveAll(r => !existingIds.Contains(r.AssignmentId));

            // Register reminders for assignments that need them
            foreach (var assignment in assignments.Where(a => !a.IsCompleted))
            {
                RegisterReminder(assignment, 60); // 1 hour before deadline
            }
        }

        private void StartReminderCheck()
        {
            _checkTimer = new System.Threading.Timer(CheckReminders, null, TimeSpan.Zero, TimeSpan.FromMinutes(1));
        }

        private void CheckReminders(object? state)
        {
            var now = DateTime.Now;
            var remindersToShow = _reminders
                .Where(r => !r.IsShown && r.ReminderTime <= now && r.ReminderTime > now.AddMinutes(-1))
                .ToList();

            if (remindersToShow.Count == 0)
                return;

            // Show reminders on UI thread
            Application.BeginInvoke(new Action(() =>
            {
                foreach (var reminder in remindersToShow)
                {
                    ShowReminder(reminder);
                    reminder.IsShown = true;
                }
                SaveReminders();
            }));
        }

        private void ShowReminder(Reminder reminder)
        {
            var timeUntilDue = reminder.DueDate - DateTime.Now;
            var timeString = timeUntilDue.TotalHours < 1
                ? $"{(int)timeUntilDue.TotalMinutes} minutes"
                : $"{(int)timeUntilDue.TotalHours} hours";

            MessageBox.Show(
                $"Reminder: {reminder.AssignmentTitle}\n" +
                $"Course: {reminder.CourseName}\n" +
                $"Due in: {timeString}\n" +
                $"Due Date: {reminder.DueDate:MM/dd/yyyy hh:mm tt}",
                "Assignment Deadline Reminder",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void LoadReminders()
        {
            if (!File.Exists(_remindersFile))
                return;

            try
            {
                var json = File.ReadAllText(_remindersFile);
                var loaded = JsonSerializer.Deserialize<List<Reminder>>(json);
                if (loaded != null)
                {
                    _reminders.Clear();
                    _reminders.AddRange(loaded);
                }
            }
            catch
            {
                // Ignore errors on load
            }
        }

        private void SaveReminders()
        {
            try
            {
                var json = JsonSerializer.Serialize(_reminders, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(_remindersFile, json);
            }
            catch
            {
                // Ignore errors on save
            }
        }

        public void Dispose()
        {
            if (_disposed) return;
            _checkTimer?.Dispose();
            _disposed = true;
        }
    }

    /// <summary>
    /// Represents a reminder for an assignment deadline.
    /// </summary>
    public class Reminder
    {
        public string AssignmentId { get; set; } = string.Empty;
        public string AssignmentTitle { get; set; } = string.Empty;
        public string CourseName { get; set; } = string.Empty;
        public DateTime DueDate { get; set; }
        public DateTime ReminderTime { get; set; }
        public bool IsShown { get; set; }
    }
}

