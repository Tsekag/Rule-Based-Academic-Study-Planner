using System.Collections.Generic;
using System.Linq;
using AcademicStudyPlanner.BusinessLogic;
using AcademicStudyPlanner.Models;

namespace AcademicStudyPlanner.Services
{
    public class WorkflowManager
    {
        // This line fixes the "_planner does not exist" error
        private readonly RuleBasedPlanner _planner = new();

        public IReadOnlyList<StudySession> RunWorkflow(PlanningWorkflow workflow, UserData userData)
        {
            var courses = userData.Courses ?? new List<CourseInfo>();
            var assignments = userData.Assignments?.Where(a => !a.IsCompleted).ToList() ?? new List<Assignment>();
            var availability = userData.Availability ?? new Availability();

            // Pass the GPA values and semester dates to make the planner "Smart"
            var sessions = _planner.GeneratePlan(
                workflow,
                courses,
                assignments,
                availability,
                userData.CurrentGPA,
                userData.TargetGPA,
                userData.SemesterStartDate,
                userData.SemesterEndDate
            );

            userData.StudyPlan = sessions;
            return sessions;
        }
    }
}