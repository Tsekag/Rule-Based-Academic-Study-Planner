partial class StudySessionBlock
{
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    // ... designer InitializeComponent() ...
}